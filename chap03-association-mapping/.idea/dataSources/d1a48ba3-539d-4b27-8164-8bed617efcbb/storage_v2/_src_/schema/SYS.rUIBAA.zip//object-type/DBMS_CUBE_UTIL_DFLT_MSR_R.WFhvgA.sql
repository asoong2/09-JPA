create type dbms_cube_util_dflt_msr_r
  as object (owner             dbms_id,
             cube_name         dbms_id,
             default_measure   dbms_id )
/

