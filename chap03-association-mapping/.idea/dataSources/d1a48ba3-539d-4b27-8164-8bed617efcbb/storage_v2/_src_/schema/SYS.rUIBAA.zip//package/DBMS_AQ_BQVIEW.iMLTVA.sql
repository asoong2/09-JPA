create PACKAGE dbms_aq_bqview wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
9
23c 11f
hjlJ0WkmbcyES46GYUv5j3lkXDQwg9f/LZ4VfC+pOMEile4ajwbY55yLXzXH3uvbJT5U9bi4
LzUPmucC5ZBE0HTum1u84U5ixawLEr6Vaiphsfg60qZ0P4xsXa+t4CyE6ctLrFYdWhekV/6D
ZRab82PQRN/abcDxGUU+67s/Ib8fy2DIE4GQJo4FOEkhjPZRya78jJyvdcm00JyW1M8qQeh3
9yhK+FVm+N8F4dlntd25FJqbPwDb2tiqYqoD45CU+mdWNZ5e6VaMFv7s/JV9vUECEjU=
/

