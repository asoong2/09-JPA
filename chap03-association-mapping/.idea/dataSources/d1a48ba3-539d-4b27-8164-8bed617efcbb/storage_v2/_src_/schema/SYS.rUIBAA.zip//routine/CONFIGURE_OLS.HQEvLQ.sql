create PROCEDURE     configure_ols wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
7
b5 eb
YJ8UzgMVCNbkMqefs7CJcEmw4N8wgy5KNZ4VfC/pTP6OAwxEKftW0YORXzfIp1ii9SqZzPPb
rAZzkPzUPQc6ThyqGq9R1Ua47BycBYFzetn1qjXqm9FXSwLnXqcVWi9TxVkjpO8MWogACbqB
fYTlpj89Ix3PkS3WPAdxE4jboHjVfLXij0fCXBYzkD21ydz0QcfAc8zyyy3Mld8wTBuEXZL2
6ja39h8sTfVlCg==
/

