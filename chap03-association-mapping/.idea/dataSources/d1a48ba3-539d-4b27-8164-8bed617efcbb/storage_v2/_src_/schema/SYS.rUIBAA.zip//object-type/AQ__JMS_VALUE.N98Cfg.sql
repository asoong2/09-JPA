create type aq$_jms_value
                                      
as object
(
  type        number(2),
  num_val     number,
  char_val    char(1),
  text_val    clob,
  bytes_val   blob
);
/

