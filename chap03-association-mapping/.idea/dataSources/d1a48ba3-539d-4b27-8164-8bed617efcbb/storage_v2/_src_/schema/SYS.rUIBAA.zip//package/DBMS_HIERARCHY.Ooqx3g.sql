create PACKAGE dbms_hierarchy AUTHID CURRENT_USER IS

  -- Constants used for upgrade log table
  VERSION_12_2_0_1 CONSTANT NUMBER := 1;
  VERSION_12_2_0_2 CONSTANT NUMBER := 2;
  VERSION_NONE     CONSTANT NUMBER := 3;
  VERSION_LATEST   CONSTANT NUMBER := VERSION_12_2_0_2;

  TABLE_DOES_NOT_EXIST EXCEPTION;
       PRAGMA EXCEPTION_INIT(TABLE_DOES_NOT_EXIST, -942);
  NAME_ALREADY_USED EXCEPTION;
      PRAGMA EXCEPTION_INIT(NAME_ALREADY_USED, -955);
  MISMATCH_OBJ_LOGNUM EXCEPTION;
      PRAGMA EXCEPTION_INIT(MISMATCH_OBJ_LOGNUM, -18263);
  MISMATCH_COL_LENGTH EXCEPTION;
      PRAGMA EXCEPTION_INIT(MISMATCH_COL_LENGTH, -18275);
  LOG_TABLE_UPGRADE EXCEPTION;
      PRAGMA EXCEPTION_INIT(LOG_TABLE_UPGRADE, -18276);

  PROCEDURE upgrade_validate_log_table(
    table_name           IN VARCHAR2,
    owner_name           IN VARCHAR2 DEFAULT
      SYS_CONTEXT('USERENV', 'CURRENT_USER'));

  PROCEDURE create_validate_log_table (
    table_name           IN VARCHAR2,
    owner_name           IN VARCHAR2 DEFAULT
      SYS_CONTEXT('USERENV', 'CURRENT_USER'),
    ignore_if_exists     IN BOOLEAN DEFAULT FALSE);

  FUNCTION validate_hierarchy (
    hier_name	 	 IN VARCHAR2,
    hier_owner_name	 IN VARCHAR2 DEFAULT
      SYS_CONTEXT('USERENV', 'CURRENT_USER'),
    log_table_name	 IN VARCHAR2 DEFAULT NULL,
    log_table_owner_name IN VARCHAR2 DEFAULT
      SYS_CONTEXT('USERENV', 'CURRENT_USER'))
  RETURN NUMBER;

  FUNCTION VALIDATE_CHECK_SUCCESS(
    topobj_name IN VARCHAR2,
    topobj_owner IN VARCHAR2 DEFAULT SYS_CONTEXT('USERENV', 'CURRENT_USER'),
    log_number IN NUMBER,
    log_table_name IN VARCHAR2 DEFAULT NULL,
    log_table_owner_name IN VARCHAR2 DEFAULT
      SYS_CONTEXT('USERENV', 'CURRENT_USER'))
  RETURN VARCHAR2;

  FUNCTION validate_analytic_view (
    analytic_view_name	     IN VARCHAR2,
    analytic_view_owner_name IN VARCHAR2 DEFAULT
      SYS_CONTEXT('USERENV', 'CURRENT_USER'),
    log_table_name	     IN VARCHAR2 DEFAULT NULL,
    log_table_owner_name     IN VARCHAR2 DEFAULT
      SYS_CONTEXT('USERENV', 'CURRENT_USER'))
  RETURN NUMBER;

  FUNCTION get_mv_sql_for_av_cache (
    analytic_view_name       IN VARCHAR2,
    cache_idx                IN NUMBER, -- 0 based cache index
    analytic_view_owner_name IN VARCHAR2 DEFAULT
      SYS_CONTEXT('USERENV', 'CURRENT_USER'))
  RETURN CLOB;

  FUNCTION is_numeric(strnum VARCHAR2) RETURN NUMBER;

END dbms_hierarchy;
/

