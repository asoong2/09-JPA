create type dbms_dbfs_content_property_t
    authid definer
as object (
    propname    varchar2(32),
    propvalue   varchar2(1024),
    typecode    integer
);
/

