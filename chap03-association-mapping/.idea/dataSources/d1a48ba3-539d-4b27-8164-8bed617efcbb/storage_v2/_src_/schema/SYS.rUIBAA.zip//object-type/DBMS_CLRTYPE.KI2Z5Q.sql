create TYPE DBMS_CLRType FORCE AS OBJECT (
  paramType             NUMBER(2),
  paramNull             NUMBER(2),
  paramDirection        NUMBER(2),
  typemapping           NUMBER(4),
  intParam              INTEGER,
  floatParam            BINARY_FLOAT,
  doubleParam           BINARY_DOUBLE,
  numberParam           NUMBER,
  dateParam             DATE,
  timestampParam        TIMESTAMP,
  timestampTZParam      TIMESTAMP WITH TIME ZONE,
  timestampLTZParam     TIMESTAMP WITH LOCAL TIME ZONE,
  intervalDSParam       INTERVAL DAY TO SECOND,
  intervalYMParam       INTERVAL YEAR TO MONTH,
  charParam             VARCHAR2(32767),
  varcharParam          VARCHAR2(32767),
  longParam             VARCHAR2(32760),
  ncharParam            NVARCHAR2(32767),
  nvarcharParam         NVARCHAR2(32767),
  rawParam              RAW(32767),
  longRawParam          RAW(32760),
  clobParam             CLOB,
  nclobParam            NCLOB,
  bfileParam            BFILE,
  blobParam             BLOB,
  rowidParam            VARCHAR2(18),
  xmltypeParam          XMLType,
  CONSTRUCTOR FUNCTION DBMS_CLRType(paramType IN BINARY_INTEGER,
    paramDirection IN BINARY_INTEGER, typemapping IN BINARY_INTEGER)
    RETURN SELF AS RESULT
);
/

