create type aq$_jms_header
                                      
as object
(
  replyto     sys.aq$_agent,
  type        varchar(100),
  userid      varchar(100),
  appid       varchar(100),
  groupid     varchar(100),
  groupseq    int,
  properties  aq$_jms_userproparray,
   --
  -- lookup_property_name checks whether new_property_name has existed
  -- in the properties.
  --
  -- @param new_property_name (IN)
  --
  -- @throws -24191 if the property name  has existed
  -- @throws -24192 if the property name  is null
  --
  MEMBER PROCEDURE lookup_property_name (new_property_name IN VARCHAR ),

  --
  -- set_replyto sets replyto which corresponds to JMSReplyTo
  --
  -- @param replyto (IN)
  --
  MEMBER PROCEDURE set_replyto (replyto IN      sys.aq$_agent),

  --
  -- set_type sets JMS type which can be any text, which
  -- corresponds to JMSType
  --
  -- @param type (IN)
  --
  MEMBER PROCEDURE set_type (type       IN      VARCHAR ),

  --
  -- set_userid sets userid which corresponds to JMSXUserID
  --
  -- @param userid (IN)
  --
MEMBER PROCEDURE set_userid (userid   IN      VARCHAR ),

  --
  -- set_appid sets appid which corresponds to JMSXAppID
  --
  -- @param appid (IN)
  --
  MEMBER PROCEDURE set_appid (appid     IN      VARCHAR ),

  --
  -- set_groupid sets groupid which corresponds to JMSXGroupID
  --
  -- @param groupid (IN)
  --
  MEMBER PROCEDURE set_groupid (groupid IN      VARCHAR ),

  --
  -- set_groupseq sets groupseq which corresponds to JMSXGroupSeq
  --
  -- @param groupseq (IN)
  --
  MEMBER PROCEDURE set_groupseq (groupseq       IN      int ),

  --
  -- clear_properties nukes properties.
  --
  MEMBER PROCEDURE clear_properties ,

  --
  -- set_boolean_property checks whether property_name is null or
  -- has existed. If not, it translates property_value into
  -- the NUMBER type since Oracle RDBMS doesnt know BOOLEAN.
  --
  -- @param property_name (IN), property_value (IN)
--
  MEMBER PROCEDURE set_boolean_property (
                property_name   IN      VARCHAR,
                property_value  IN      BOOLEAN ),

  --
  -- set_byte_property checks whether property_name is null or
  -- has existed. If not, it checks whether property_value
  -- is within -128 to 127 (8-bits) because both PL/SQL and Oracle
  -- RDBMS dont have the type byte.
  --
  -- @param property_name (IN), property_value (IN)
  --
  -- @throws -24193 if the property value excceeds the valid range
  --
  MEMBER PROCEDURE set_byte_property (
                property_name   IN      VARCHAR,
                property_value  IN      int ),

  --
  -- set_short_property checks whether property_name is null or
  -- has existed. If not, it checks whether property_value
  -- is within -32768 to 32767 (16-bits) because both PL/SQL
  -- and Oracle RDBMS dont have the type short.
  --
  -- @param property_name (IN), property_value (IN)
  --
  -- @throws -24193 if the property value excceeds the valid range
  --
  MEMBER PROCEDURE set_short_property (
                property_name   IN      VARCHAR,
                property_value  IN      int ),

  --
  -- set_int_property checks whether property_name is null or
  -- has existed. If not, it checks whether property_value
  -- is within -2147483648 to 2147483647 (32-bits) because in
  -- both PL/SQL and Oracle RDBMS the type int (or INTEGER) is
  -- 38 bit.
  --
  -- @param property_name (IN), property_value (IN)
  --
  -- @throws -24193 if the property value excceeds the valid range
  --
  MEMBER PROCEDURE set_int_property (
                property_name   IN      VARCHAR,
                property_value  IN      int ),
--
  -- set_long_property checks whether property_name is null or
  -- has existed. If not, it stores the property_value.
  -- In Java the type long is 64-bit long. In
  -- both PL/SQL and Oracle RDBMS the type NUMBER is
  -- 38 bit. So there is no need to check the range.
  --
  -- @param property_name (IN), property_value (IN)
  --
  MEMBER PROCEDURE set_long_property (
                property_name   IN      VARCHAR,
                property_value  IN      NUMBER ),

  --
  -- set_float_property checks whether property_name is null or
  -- has existed. If not, it stores the property_value.
  --
  -- @param property_name (IN), property_value (IN)
  --
  MEMBER PROCEDURE set_float_property (
                property_name   IN      VARCHAR,
                property_value  IN      FLOAT ),

  --
  -- set_double_property checks whether property_name is null or
  -- has existed. If not, it stores the property_value.
  --
  -- @param property_name (IN), property_value (IN)
  --
  MEMBER PROCEDURE set_double_property (
                property_name   IN      VARCHAR,
                property_value  IN      DOUBLE PRECISION ),

  --
  -- set_string_property checks whether property_name is null or
  -- has existed. If not, it stores the property_value.
  --
  -- @param property_name (IN), property_value (IN)
  --
  MEMBER PROCEDURE set_string_property (
                property_name   IN      VARCHAR,
                property_value  IN      VARCHAR ),

  --
  -- get_replyto returns replyto which corresponds to JMSReplyTo.
  --
  -- @return sys.aq$_agent
  --
  MEMBER FUNCTION get_replyto RETURN sys.aq$_agent,
 --
  -- get_type returns type which corresponds to JMSType.
  --
  -- @return VARCHAR
  --
  MEMBER FUNCTION get_type RETURN VARCHAR,

  --
  -- get_userid returns userid which corresponds to JMSXUserID.
  --
  -- @return VARCHAR
  --
  MEMBER FUNCTION get_userid RETURN VARCHAR,

  --
  -- get_appid returns appid which corresponds to JMSXAppID.
  --
  -- @return VARCHAR
  --
  MEMBER FUNCTION get_appid RETURN VARCHAR,

  --
  -- get_groupid returns groupid which corresponds to JMSXGroupID.
  --
  -- @return VARCHAR
  --
  MEMBER FUNCTION get_groupid RETURN VARCHAR,

  --
  -- get_groupseq returns groupseq which corresponds to JMSXGroupSeq.
  --
  -- @return int
  --
  MEMBER FUNCTION get_groupseq RETURN int,

  --
  -- get_boolean_property returns a BOOLEAN value if it can find
  -- property_name and its java_type is BOOLEAN, and returns a NULL
  -- if it cannot find.
  --
  -- @param property_name (IN)
  --
  -- @return BOOLEAN
  --
  MEMBER FUNCTION get_boolean_property ( property_name   IN      VARCHAR)
  RETURN   BOOLEAN,
 --
  -- get_boolean_property_as_int returns 1 (for TRUE) and 0 (for FALSE)
  -- value if it can find property_name and its java_type is BOOLEAN,
  -- and returns a NULL otherwise.
  --
  -- @param property_name (IN)
  --
  -- @return int
  --
  MEMBER FUNCTION get_boolean_property_as_int ( property_name   IN   VARCHAR)
  RETURN   int,

  --
  -- get_byte_property returns a "byte" value if it can find
  -- property_name and its java_type is byte, and returns a NULL
  -- if it cannot find.
  --
  -- @param property_name (IN)
  --
  -- @return int
  --
  MEMBER FUNCTION get_byte_property ( property_name   IN      VARCHAR)
  RETURN   int,

  --
  -- get_short_property returns a "short" value if it can find
  -- property_name and its java_type is short, and returns a NULL
  -- if it cannot find.
  --
  -- @param property_name (IN)
  --
  -- @return int
  --
  MEMBER FUNCTION get_short_property ( property_name   IN      VARCHAR)
  RETURN   int,

  --
  -- get_int_property returns a int value if it can find
  -- property_name and its java_type is int, and returns a NULL
  -- if it cannot find.
  --
  -- @param property_name (IN)
  --
  -- @return int
  --
  MEMBER FUNCTION get_int_property ( property_name   IN      VARCHAR)
  RETURN   int,

  --
  -- get_long_property returns a int value if it can find
  -- property_name and its java_type is long, and returns a NULL
  -- if it cannot find.
 --
  -- @param property_name (IN)
  --
  -- @return NUMBER
  --
  MEMBER FUNCTION get_long_property ( property_name   IN      VARCHAR)
  RETURN   NUMBER,

  --
  -- get_float_property returns a FLOAT value if it can find
  -- property_name and its java_type is float, and returns a NULL
  -- if it cannot find.
  --
  -- @param property_name (IN)
  --
  -- @return FLOAT
  --
  MEMBER FUNCTION get_float_property ( property_name   IN      VARCHAR)
  RETURN   FLOAT,

  --
  -- get_double_property returns a DOUBLE PRECISION value if it can find
  -- property_name and its java_type is double, and returns a NULL
  -- if it cannot find.
  --
  -- @param property_name (IN)
  --
  -- @return DOUBLE PRECISION
  --
  MEMBER FUNCTION get_double_property ( property_name   IN      VARCHAR)
  RETURN   DOUBLE PRECISION,

  --
  -- get_string_property returns a varchar value if it can find
  -- property_name and its java_type is string, and returns a NULL
  -- if it cannot find.
  --
  -- @param property_name (IN)
  --
  -- @return VARCHAR
  --
  MEMBER FUNCTION get_string_property ( property_name   IN      VARCHAR)
  RETURN   VARCHAR

);
/

