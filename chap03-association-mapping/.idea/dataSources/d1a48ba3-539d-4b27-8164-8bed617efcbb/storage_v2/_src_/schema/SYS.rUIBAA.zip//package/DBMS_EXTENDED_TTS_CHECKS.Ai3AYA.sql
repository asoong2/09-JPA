create PACKAGE     DBMS_EXTENDED_TTS_CHECKS IS

  --++
  -- Definition:  This function verifies Schema based XMLType tables that are
  --              part of the transport set are self contained. i.e. the out of
  --              line pieces that the table points to are also part of the
  --              transport set. This will ensure that the SB XMLType table is
  --              self contained.
  --
  -- Inputs:      tsnames - plsql table of tablespace names
  --              fromexp - stop after first violation found
  --
  -- Outputs:     None
  --
  -- Returns:     If fromExp is true, return false if violation found, true
  --              for all other cases(even if violations have been found).
  --++
  FUNCTION verify_XMLSchema(
        tsnames         IN dbms_tts.ts_names_tab_t,
        fromExp         IN BOOLEAN)
    RETURN BOOLEAN;

  --++
  -- Function      check_csx_closure
  --
  -- Description:  Verifies that all token manager tables for XML tables and
  --               columns with binary storage (CSX) are also contained in the
  --               transported tablespaces. This is needed so that data at the
  --               import site can be decoded without a full remapping.
  --
  --               To be combined with verify_XMLSchema.
  --
  -- Inputs:       tsnames  - comma separated list of tablespace names
  --               fromExp  - being called by export?
  --
  -- Outputs:      None
  --
  -- Results       True if contained, otherwise false.
  --               As for verify_XMLSchema, even if violation is found, returns
  --               true if from Exp is false.
  --++
  FUNCTION check_csx_closure(
        tsnames         IN dbms_tts.ts_names_tab_t,
        fromExp         IN BOOLEAN )
    RETURN BOOLEAN;

  --++
  -- Definition:  This function verifies secondary objects that are associated
  --              with an extensible index are contained in the list of
  --              tablespaces or fully outside the list. This guarantees self
  --              containment of all or none of the secondary objects
  --              associated with the extensible index. For simple types like
  --              tables and indexes it is clear why this check works. What may
  --              not be so obvious is that this works even for objects like
  --              partitions, lobs etc.  For e.g. if Table T1 is partitioned
  --              two ways P1 and P2, has a lob object L1 and Table T2 is an
  --              IOT, and extensible index E1 is associated with L1 and T2
  --              then it is sufficient just check that tablespace(L1) and
  --              tablespace(T2) are either fully contained or fully out of
  --              the tts set. Self Containment of T1 and T2 is guaranteed by
  --              the straddling_rs_objects function
  --
  -- Inputs:      fromexp - stop after first violation found
  --
  -- Outputs:     None
  --
  -- Returns:     If fromExp is true, return false if violation found, true
  --              for all other cases (even if violations have been found).
  --++
  FUNCTION verify_Extensible(
        fromExp IN BOOLEAN)
    RETURN BOOLEAN;

  --++
  -- Definition :  This function verifies that:
  --               1. Materialized view logs stored as tables and the
  --                  corresponding master tables are self contained. The
  --                  containment check is similar to tables and its indexes:
  --                  If full_check is TRUE, then BOTH the MV log and the
  --                  master table must be in or both must be out of the
  --                  transportable set. If full_check is FALSE, then it is ok
  --                  for the MV log to be out of the transportable set but it
  --                  is NOT ok for the MV log to be in and its master table to
  --                  be out of the set.
  --               2. Updateable Materialized view tables and their
  --                  corresponding logs are fully contained in the
  --                  transportable set.
  --
  --               If fromExp is false, populate the violation table with the
  --               offending violation object information for each violation.
  --
  --               Note that it is ok to transport just the MVs and not their
  --               masters or vice versa. It is also ok to just transport
  --               master tables without the mv logs, but NOT vice versa.
  --
  -- Inputs:      fromexp    - stop after first violation found
  --              full_check - perform full check - described above
  --
  -- Outputs:     None
  --
  -- Returns:     If fromExp is true, return false if violation found, true
  --              for all other cases (even if violations have been found).
  --++
  FUNCTION verify_MV(
        fromExp         IN BOOLEAN,
        full_check      IN BOOLEAN)
    RETURN BOOLEAN;

  --++
  -- Definition:  This function verifies that all nested tables are fully in or
  --              out of the tts set.
  --
  -- Inputs:      fromexp    - stop after first violation found
  --
  -- Outputs:     None
  --
  -- Returns:     If fromExp is true, return false if violation found, true
  --              for all other cases (even if violations have been found).
  --++
  FUNCTION verify_NT(
        fromExp IN BOOLEAN)
    RETURN BOOLEAN;

  --
  -- The following get_tablespace_* functions take information about an object
  -- that takes up physical storage in the database and returns the tablespace
  -- name associated with the object.
  --

  --++
  -- Definition:  This function checks if table is non partitioned and not an
  --              IOT then return its tablespace.  If the TABLE is an IOT or
  --              partitioned then just return the tablespace associated with
  --              the index or the first partition respectively. If a specific
  --              tablespace is needed then the get_tablespace_tabpart routine
  --              should be invoked by the caller.
  --
  -- Inputs:      objnum      - obj# of object to check
  --              schemaname  - owner of object
  --              objname     - object name
  --              subname     - object subname (partition or subpartition)
  --              objtype     - object type
  --
  -- Outputs:     None
  --
  -- Returns:     Tablespace name
  --++
  FUNCTION get_tablespace_tab(
        objnum          IN NUMBER,
        schemaname      IN VARCHAR2,
        objname         IN VARCHAR2,
        subname         IN VARCHAR2,
        objtype         IN VARCHAR2)
    RETURN VARCHAR2;

END DBMS_EXTENDED_TTS_CHECKS;
/

