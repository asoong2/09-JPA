create package dbms_dnfs AUTHID CURRENT_USER AS

-- DE-HEAD  <- tell SED where to cut when generating fixed package


  -- Renames files in the dNFS test database to the new name. The new file
  -- points to the original file for reads.
  --
  -- srcfile - source data file name in the control file
  -- destfile - destination file
  --
  PROCEDURE clonedb_renamefile (srcfile  IN varchar2,
                                destfile  IN varchar2
                                );

  -- This is the equivalent of the unmount command used to unmount an NFS
  -- volume. unmountvolume cleans up the cached mount handles in the
  -- database SGA. If volumes are deleted and recreated with the same name,
  -- this will prevent false cache hits and stale file handle errors.
  --
  -- server - NFS server that hosts the volume to be unmounted.
  -- volume - Volume that needs to be unmounted.
  --

  PROCEDURE unmountvolume(server IN varchar2, volume IN varchar2);


  procedure restore_datafile_permissions(pdb_name IN varchar2 DEFAULT NULL);
  -- NAME:
  -- restore_datafile_permissions - Restore datafile permissions to Read/Write
  --
  -- DESCRIPTION:
  --   This procedure restores a PDB's datafile permissions to Read/Write.
  --
  -- PARAMETERS:
  -- pdb_name - name of the PDB for which datafile permissions are to be
  --            restored. If null, datafile permissions for current PDB
  --            connection will be restored.

-------------------------------------------------------------------------------

pragma TIMESTAMP('2010-07-08:12:00:00');

-------------------------------------------------------------------------------


end;

-- CUT_HERE    <- tell sed where to chop off the rest
/

