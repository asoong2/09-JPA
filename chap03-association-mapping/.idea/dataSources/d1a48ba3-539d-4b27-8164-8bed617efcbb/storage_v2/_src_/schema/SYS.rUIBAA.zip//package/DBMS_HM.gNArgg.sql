create PACKAGE dbms_hm AS

-- DE-HEAD  <- tell SED where to cut when generating fixed package

--*****************************************************************************
-- Package Public Exceptions
--*****************************************************************************

--*****************************************************************************
-- Package Public Types
--*****************************************************************************

--*****************************************************************************
-- HM RUN CHECK Implementation
--*****************************************************************************

-------------------------------------------------------------------------------
--
-- PROCEDURE     run_check
--
-- Description:  Runs a given check
--
-- Parameters:   check_name - check name
--               run_name   - run name to uniquely identify this run
--               timeout    - timeout for the given run (in seconds)
--               input_params   - text format of input parameters
--
-------------------------------------------------------------------------------
PROCEDURE run_check( check_name    IN varchar2,
                     run_name      IN varchar2 := null,
                     timeout       IN number := null,
                     input_params  IN varchar2 := null);

------------------------------------------------------------------------------
--
-- FUNCTION      get_run_report
--
-- Description:  Gets the report for a given run name
--
-- Parameters:   run_name  -  run name
--               report_type      -  type of report (TEXT, HTML, XML)
--               report_level     -  Level of report (BASIC, DETAILED)
--
-------------------------------------------------------------------------------

FUNCTION get_run_report(run_name IN varchar2,
                        report_type IN varchar2 := 'TEXT',
                        report_level IN varchar2 := 'BASIC' ) return clob;

-------------------------------------------------------------------------------
--
-- PROCEDURE     create_schema
--
-- Description:  creates HM schema in ADR
--
-- Parameters:
--
-------------------------------------------------------------------------------
PROCEDURE create_schema;

-------------------------------------------------------------------------------
--
-- PROCEDURE     drop_schema
--
-- Description:  drops HM schema
--
-- Parameters:  force   -
--
-------------------------------------------------------------------------------
PROCEDURE drop_schema(force IN boolean := FALSE);
-------------------------------------------------------------------------------

--*****************************************************************************
-- HM - DDE User Action  Implementation
--*****************************************************************************

-------------------------------------------------------------------------------
--
-- FUNCTION      run_dde_action
--
-- Description:  Runs a DDE (user) action for HM checks.
--
-- Parameters:   incident_id    -   Incident ID
--               directory_name -   directory info(should be NULL for HM)
--               check_name     -   check to be executed
--               run_name       -   run name given for the run/action(NULL??)
--               timeout        -   timeout for the given run (in seconds)
--               params         -   text format of input parameters
--
-------------------------------------------------------------------------------
FUNCTION run_dde_action( incident_id         IN number,
                         directory_name      IN varchar2,
                         check_name          IN varchar2,
                         run_name            IN varchar2,
                         timeout             IN number,
                         params              IN varchar2) return boolean;

-------------------------------------------------------------------------------
--
-- PROCEDURE     create_offline_dictionary
--
-- Description:  creates LogMiner offline dictionary in ADR
--
-- Parameters:
--
-------------------------------------------------------------------------------
PROCEDURE create_offline_dictionary;

END;

-- CUT_HERE    <- tell sed where to chop off the rest
/

