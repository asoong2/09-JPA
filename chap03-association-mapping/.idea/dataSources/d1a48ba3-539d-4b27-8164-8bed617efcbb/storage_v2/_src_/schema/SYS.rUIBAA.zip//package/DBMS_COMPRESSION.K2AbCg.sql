create package dbms_compression authid current_user is

COMP_NOCOMPRESS               CONSTANT NUMBER := 1;
COMP_ADVANCED                 CONSTANT NUMBER := 2;
COMP_QUERY_HIGH               CONSTANT NUMBER := 4;
COMP_QUERY_LOW                CONSTANT NUMBER := 8;
COMP_ARCHIVE_HIGH             CONSTANT NUMBER := 16;
COMP_ARCHIVE_LOW              CONSTANT NUMBER := 32;
COMP_BLOCK                    CONSTANT NUMBER := 64;
COMP_LOB_HIGH                 CONSTANT NUMBER := 128;
COMP_LOB_MEDIUM               CONSTANT NUMBER := 256;
COMP_LOB_LOW                  CONSTANT NUMBER := 512;
COMP_INDEX_ADVANCED_HIGH      CONSTANT NUMBER := 1024;
COMP_INDEX_ADVANCED_LOW       CONSTANT NUMBER := 2048;
COMP_BASIC                    CONSTANT NUMBER := 4096;
COMP_INMEMORY_NOCOMPRESS      CONSTANT NUMBER := 8192;
COMP_INMEMORY_DML             CONSTANT NUMBER := 16384;
COMP_INMEMORY_QUERY_LOW       CONSTANT NUMBER := 32768;
COMP_INMEMORY_QUERY_HIGH      CONSTANT NUMBER := 65536;
COMP_INMEMORY_CAPACITY_LOW    CONSTANT NUMBER := 131072;
COMP_INMEMORY_CAPACITY_HIGH   CONSTANT NUMBER := 262144;

COMP_RATIO_MINROWS            CONSTANT NUMBER := 1000000;
COMP_RATIO_ALLROWS            CONSTANT NUMBER := -1;
COMP_RATIO_LOB_MINROWS        CONSTANT NUMBER := 1000;
COMP_RATIO_LOB_MAXROWS        CONSTANT NUMBER := 5000;
COMP_RATIO_INDEX_MINROWS      CONSTANT NUMBER := 100000;

OBJTYPE_TABLE                 CONSTANT NUMBER := 1;
OBJTYPE_INDEX                 CONSTANT NUMBER := 2;
OBJTYPE_PART                  CONSTANT NUMBER := 3;
OBJTYPE_SUBPART               CONSTANT NUMBER := 4;

--Record for calculating an individual index cr on a table
type compRec is record(
  ownname           varchar2(255),
  objname           varchar2(255),
  blkcnt_cmp        PLS_INTEGER,
  blkcnt_uncmp      PLS_INTEGER,
  row_cmp           PLS_INTEGER,
  row_uncmp         PLS_INTEGER,
  cmp_ratio         NUMBER,
  objtype           PLS_INTEGER
);

type compRecList is table of compRec;

  --Get compression ratio for an object: table/index. Default is table.
  PROCEDURE get_compression_ratio(
    scratchtbsname        IN     varchar2,
    ownname               IN     varchar2,
    objname               IN     varchar2,
    subobjname            IN     varchar2,
    comptype              IN     number,
    blkcnt_cmp            OUT    PLS_INTEGER,
    blkcnt_uncmp          OUT    PLS_INTEGER,
    row_cmp               OUT    PLS_INTEGER,
    row_uncmp             OUT    PLS_INTEGER,
    cmp_ratio             OUT    NUMBER,
    comptype_str          OUT    varchar2,
    subset_numrows        IN     number  DEFAULT COMP_RATIO_MINROWS,
    objtype               IN     PLS_INTEGER DEFAULT OBJTYPE_TABLE
  );

  --Get compression ratio for lobs
  PROCEDURE get_compression_ratio(
    scratchtbsname        IN     varchar2,
    tabowner              IN     varchar2,
    tabname               IN     varchar2,
    lobname               IN     varchar2,
    partname              IN     varchar2,
    comptype              IN     number,
    blkcnt_cmp            OUT    PLS_INTEGER,
    blkcnt_uncmp          OUT    PLS_INTEGER,
    lobcnt                OUT    PLS_INTEGER,
    cmp_ratio             OUT    NUMBER,
    comptype_str          OUT    varchar2,
    subset_numrows        IN     number DEFAULT COMP_RATIO_LOB_MAXROWS
  );


  --Get compression ratio for all indexes on a table. The compression
  --ratios will be returned as a collection.
  PROCEDURE get_compression_ratio(
    scratchtbsname        IN     varchar2,
    ownname               IN     varchar2,
    tabname               IN     varchar2,
    comptype              IN     number,
    index_cr              OUT    compRecList,
    comptype_str          OUT    varchar2,
    subset_numrows        IN     number DEFAULT COMP_RATIO_INDEX_MINROWS
  );

  function get_compression_type (
    ownname         IN varchar2,
    tabname         IN varchar2,
    row_id          IN rowid,
    subobjname      IN varchar2 DEFAULT NULL
  )
    return number;

  PROCEDURE dump_compression_map (
    ownname         IN varchar2,
    tabname         IN varchar2,
    comptype        IN number
  );

/*      SYNTAX:
          call incremental_compress(<Owner name>, <Table name>, <Partition Name>, <Column Name>, [Dump], [Auto Compress], [Where Clause]);
          <Owner Name>:     Name of the owner of the table
          <Table Name>:     Name of table under consideration
          <Partition Name>: If the table is partitioned (or sub-partitioned), specify the specific partition (or sub-partition)
                            name here. If the table is sub-partitioned, then each sub-partition will have to be compressed
                            separately. For tables that are not partitioned, this parameter is ignored, so a '' can be specified.
                            NOTE: Each partition or subpartition will have to be compressed separately. It is erroneous to
                            specify a partition name for a table with sub-partitions. The specific sub-partition name will
                            have to be specified.
          <Column Name>:    This column can be any column name in the table. An update statement of the type
                            'update table_name set column_name = column_name' will be run, so choosing any column name should
                            not make any functional difference.
          [Dump]:           An optional parameter that dumps out the space saved in each block into the trace files. It is turned
                            OFF by default (set to 0). It is advised not to turn this feature on for large tables or partitions
                            because of excessive logging.
          [Auto Compress]:  If table is not created compressed or compression was never used on this table/partition, setting this to 1 will
                            force an alter table to switch on and then switch off compression on this table/partition.
          [Where Clause]:   An optional where clause supplied to the update statement. */

  PROCEDURE incremental_compress (
        ownname            IN dba_objects.owner%type,
        tabname            IN dba_objects.object_name%type,
        partname           IN dba_objects.subobject_name%type,
        colname            IN varchar2,
        dump_on            IN number default 0,
        autocompress_on    IN number default 0,
        where_clause       IN varchar2 default '');

  PROCEDURE clear_analysis (
        ownname         IN varchar2,
        tabname         IN varchar2,
        comptype        IN number default 0);


end dbms_compression;
/

