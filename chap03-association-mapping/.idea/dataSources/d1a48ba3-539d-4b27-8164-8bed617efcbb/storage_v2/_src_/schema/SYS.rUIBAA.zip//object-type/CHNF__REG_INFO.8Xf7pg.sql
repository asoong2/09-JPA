create type     chnf$_reg_info as object (
       callback varchar2(64),
       qosflags number,
       timeout number,
       operations_filter number,
       transaction_lag number,
       ntfn_grouping_class        NUMBER,    -- ntfn grouping class
       ntfn_grouping_value        NUMBER,    -- ntfn grouping value
       ntfn_grouping_type         NUMBER,    -- ntfn grouping type
       ntfn_grouping_start_time   TIMESTAMP WITH TIME ZONE, -- grp start time
       ntfn_grouping_repeat_count NUMBER,    -- ntfn grp repeat count
       CONSTRUCTOR FUNCTION chnf$_reg_info(
         callback varchar2,
         qosflags number,
         timeout number)
       RETURN SELF AS RESULT ,   -- basic type without any frills
       CONSTRUCTOR FUNCTION chnf$_reg_info(
         callback varchar2,
         qosflags number,
         timeout number,
         operations_filter number,
         transaction_lag number)  -- 10gR2 type for backward compat
       RETURN SELF AS RESULT,
       CONSTRUCTOR FUNCTION chnf$_reg_info(
         callback varchar2,
         qosflags number,
         timeout number,
         operations_filter number,
         ntfn_grouping_class        NUMBER,
         ntfn_grouping_value        NUMBER,
         ntfn_grouping_type         NUMBER,
         ntfn_grouping_start_time   TIMESTAMP WITH TIME ZONE,
         ntfn_grouping_repeat_count NUMBER)
         RETURN SELF AS RESULT
         )                    -- depracating the transaction_lag param
 alter type     chnf$_reg_info modify attribute callback varchar2(257)
  cascade
/

