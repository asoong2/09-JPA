create PACKAGE dbms_goldengate_adm AUTHID CURRENT_USER AS

  -- CONSTANTS
  use_custom_handlers_none    CONSTANT BINARY_INTEGER := 0;
  use_custom_handlers_all     CONSTANT BINARY_INTEGER := 1;

  PROCEDURE insert_procrep_exclusion_obj(
    package_owner     IN varchar2 default NULL,
    package_name      IN varchar2 default NULL,
    object_owner      IN varchar2 default NULL,
    object_name       IN varchar2 default NULL);

  PROCEDURE delete_procrep_exclusion_obj(
    package_owner     IN varchar2 default NULL,
    package_name      IN varchar2 default NULL,
    object_owner      IN varchar2 default NULL,
    object_name       IN varchar2 default NULL);

  -- Configures automatic CDR
  -- INPUT:
  --   schema_name          - owner of table
  --   table_name           - table name
  --   resolution_granularity - ROW or COLUMN granularity
  --   existing_data_timestamp- timestamp to assign existing rows
  --   tombstone_deletes      - track deletes in tombstone able?
  --   fetchcols              - fetch nonscalar columns
  --   record_conflicts       - record conflict info
  --   use_custom_handlers    - use custom handlers
  -- OUTPUT:
  -- NOTES:
  PROCEDURE add_auto_cdr(
	schema_name             IN VARCHAR2,
	table_name              IN VARCHAR2,
        resolution_granularity  IN VARCHAR2 DEFAULT 'ROW',
	existing_data_timestamp IN TIMESTAMP WITH TIME ZONE DEFAULT NULL,
        tombstone_deletes       IN BOOLEAN DEFAULT TRUE,
        fetchcols               IN BOOLEAN DEFAULT TRUE,
        record_conflicts        IN BOOLEAN DEFAULT FALSE,
        use_custom_handlers     IN BINARY_INTEGER DEFAULT 0);

  -- Remove automatic CDR configuration
  -- INPUT:
  --   schema_name          - table owner
  --   table_name           - table name
  -- OUTPUT:
  -- NOTES:
  PROCEDURE remove_auto_cdr(
	schema_name             IN VARCHAR2,
	table_name              IN VARCHAR2);

  -- Alter automatic CDR configuration
  -- INPUT:
  --   schema_name          - table owner
  --   table_name           - table name
  --   tombstone_deletes    - track deletes in tombstone able?
  --   fetchcols            - fetch nonscalar columns
  --   record_conflicts     - record conflict info
  --   use_custom_handlers  - use custom handlers
  -- OUTPUT:
  -- NOTES:
  PROCEDURE alter_auto_cdr(
	schema_name             IN VARCHAR2,
	table_name              IN VARCHAR2,
        tombstone_deletes       IN BOOLEAN DEFAULT NULL,
        fetchcols               IN BOOLEAN DEFAULT NULL,
        record_conflicts        IN BOOLEAN DEFAULT NULL,
        use_custom_handlers     IN BINARY_INTEGER DEFAULT NULL);

  -- Add automatic CDR delta resolution
  -- INPUT:
  --   schema_name          - table owner
  --   table_name           - table name
  --   column_name          - column name
  -- OUTPUT:
  -- NOTES:
  PROCEDURE add_auto_cdr_delta_res(
	schema_name             IN VARCHAR2,
	table_name              IN VARCHAR2,
        column_name             IN VARCHAR2);

  -- Remove automatic CDR delta resolution
  -- INPUT:
  --   schema_name          - table owner
  --   table_name           - table name
  --   column_name          - column name
  -- OUTPUT:
  -- NOTES:
  PROCEDURE remove_auto_cdr_delta_res(
	schema_name             IN VARCHAR2,
	table_name              IN VARCHAR2,
        column_name             IN VARCHAR2);

  -- Add automatic CDR column group
  -- INPUT:
  --   schema_name          - table owner
  --   table_name           - table name
  --   column_list          - column list
  --   column_group_name    - column group name
  --   existing_data_timestamp - timestamp for existing rows
  -- OUTPUT:
  -- NOTES:
  PROCEDURE add_auto_cdr_column_group(
	schema_name             IN VARCHAR2,
	table_name              IN VARCHAR2,
        column_list             IN VARCHAR2,
        column_group_name       IN VARCHAR2 default NULL,
        existing_data_timestamp IN TIMESTAMP WITH TIME ZONE DEFAULT NULL);

  -- Remove automatic CDR column group
  -- INPUT:
  --   schema_name          - table owner
  --   table_name           - table name
  --   column_group_name    - column group name
  -- OUTPUT:
  -- NOTES:
  PROCEDURE remove_auto_cdr_column_group(
	schema_name             IN VARCHAR2,
	table_name              IN VARCHAR2,
        column_group_name       IN VARCHAR2);

  -- Alter automatic CDR column group
  -- INPUT:
  --   schema_name          - table owner
  --   table_name           - table name
  --   column_group_name    - column group name
  --   add_column_list      - columns to add
  --   remove_column_list   - columns to remove
  -- OUTPUT:
  -- NOTES:
  PROCEDURE alter_auto_cdr_column_group(
	schema_name             IN VARCHAR2,
	table_name              IN VARCHAR2,
        column_group_name       IN VARCHAR2,
        add_column_list         IN VARCHAR2,
        remove_column_list      IN VARCHAR2);

  -- Purge tombstone tables
  -- INPUT:
  --   purge_timestamp       - purge records before this timestamp
  -- OUTPUT:
  -- NOTES:
  PROCEDURE purge_tombstones(purge_timestamp IN TIMESTAMP WITH TIME ZONE);

  FUNCTION gg_procedure_replication_on RETURN NUMBER;

-- Update the High-watermark for all Identity column sequence objects in the
-- database instance.  For every table having an identity column, this procedure
-- updates the high watermark of the corresponding system-generated sequence
-- object to be higher than any value in the identity column (or lower in the
-- case of a decreasing sequence).  Invoke this routine on an instance before
-- switching it from a target instance to a source instance, so that subsequent
-- identity column DMLs don't insert duplicate values.
  PROCEDURE update_identity_column_hwm;
END dbms_goldengate_adm;
/

