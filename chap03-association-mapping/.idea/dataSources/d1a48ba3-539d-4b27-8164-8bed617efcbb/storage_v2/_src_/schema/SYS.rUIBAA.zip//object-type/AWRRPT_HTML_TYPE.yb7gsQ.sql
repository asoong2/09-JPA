create type AWRRPT_HTML_TYPE
  as object (output varchar2(8000 CHAR))
/

