create type aq$_jms_userproperty
                                      
as object
(
  name        varchar(100),
  type        int,
  str_value   varchar(2000),
  num_value   NUMBER,
  java_type   int
);
/

