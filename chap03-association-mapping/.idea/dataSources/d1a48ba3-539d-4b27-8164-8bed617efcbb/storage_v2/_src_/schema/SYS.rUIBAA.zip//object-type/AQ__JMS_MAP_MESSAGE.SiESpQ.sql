create type aq$_jms_map_message
                                       authid current_user
as object
(
  header     aq$_jms_header,
  bytes_len  int,
  bytes_raw  raw(2000),
  bytes_lob  blob,
  STATIC FUNCTION construct RETURN aq$_jms_map_message,


  -- *******************************************
  -- The following are common procedures of aq$_jms_stream_message,
  -- aq$_jms_bytes_message and aq$_jms_map_message types to synchronize
  -- the data between JAVA stored procedure and PL/SQL.
  -- *******************************************

  --============================================
  -- Get the JAVA exception thrown during the previous failure.
  -- Only one JAVA exception is recorded for a session. If the
  -- exception is not fetched in time, it might be overwritten
  -- by the exception thrown in next failure.

  STATIC FUNCTION get_exception
  RETURN AQ$_JMS_EXCEPTION,


  --============================================
  -- Clean all the messages in the JVM session memory.
  --

  STATIC PROCEDURE clean_all,


  --============================================
  -- Populate the data at JAVA stored procedure with the data at PL/SQL side.
  --
  -- Underlying, it takes the RAW/BLOB stored in PL/SQL aq$_jms_map_message
  -- to construct a JAVA object (for aq$_jms_map_message is Hashtable)
  -- which is stored in ORACLE JVM session memeory.
  --
  -- Parameter "id" is called operation id that is used to identify the slot
  -- where the JAVA object is stored in the ORACLE JVM session memeory.
  -- If "id" is NULL, a new slot is created for this PL/SQL object.
  -- Later JMS operations on the payload need to provide this operation id.
  --
  -- Parameters:
  --  id  - the operation id for this ADT instance.
  --        if id is negative, the system will create a new operation id.
  --
  -- Returns:
  --  the operation id.
  --
  -- There is no message access mode concept in aq$_jms_map_message.
  -- The map message can be both written and read at any time and change is reflect immediately.
  --
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
  -- Raise ORA-24198: Invalid operation id.
  -- Raise ORA-24199: JAVA store procedure message store overflow.
 MEMBER FUNCTION prepare (id IN PLS_INTEGER)
  RETURN PLS_INTEGER,


  --============================================
  -- Set the data at JAVA stored procedure as empty payload.
  --
  -- Underlying, it initialize an new Hashtable object and set it to
  -- the static varaible in ORACLE JVM session memeory.
  --
  -- Parameter "id" is called operation id that is used to identify the slot
  -- where the JAVA object is stored in the ORACLE JVM session memeory.
  -- If "id" is NULL, a new slot is created for this PL/SQL object.
  -- Later JMS operations on the payload need to provide this operation id.
  --
  -- Parameters:
  --  id  - the operation id for this ADT instance.
  --        if id is negative, the system will create a new operation id.
  --
  -- Returns:
  --  the operation id.
  --
  -- There is no message access mode concept in aq$_jms_map_message.
  -- The map message can be both written and read at any time and change is reflect immediately.
  --
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
  -- Raise ORA-24198: Invalid operation id.
  -- Raise ORA-24199: JAVA store procedure message store overflow.

  MEMBER FUNCTION clear_body (id IN PLS_INTEGER)
  RETURN PLS_INTEGER,

  --============================================
  -- Flush the data at JAVA stored procedure side to PL/SQL side.
  --
  -- Underlying, it update the data at PL/SQL side to the payload stored at
  -- the JAVA stored procedure side.
  --
  -- Parameters:
  --  id  - the operation id for this ADT instance.
  --
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
  -- Raise ORA-24198: Invalid operation id.

  MEMBER PROCEDURE flush (id IN PLS_INTEGER),

--============================================
  -- clean the data at JAVA stored procedure side to PL/SQL side.
  --
  -- Underlying, it set the static variable of Hashtable to null
  -- at the JAVA stored procedure side corresponding to the operation id.
  -- It is very import to call this procedure to avoid memeory leak!
  --
  -- Parameters:
  --  id  - the operation id for this ADT instance.
  --
  -- Raise ORA-24198: Invalid operation id.

  MEMBER PROCEDURE clean (id IN PLS_INTEGER),


  --*******************************************
  -- JMS operations member functions and procedures
  --*******************************************

  --============================================
  -- Retrieve the size of the map message.
  --
  -- Parameters:
  --  id   - the operation id for this ADT instance.
  --
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
  -- Raise ORA-24198: Invalid operation id.

  MEMBER FUNCTION get_size (id IN PLS_INTEGER)
  RETURN PLS_INTEGER,


  --============================================
  -- Retrieve all the names within the map message.
  -- Since aq$_jms_namearray has a size of 1024 and each element a varchar(200),
  -- this function raise error if either of sizes limit is exceeded.
  --
  -- Parameters:
  --  id   - the operation id for this ADT instance.
  --
  -- Raise ORA-24195: size of the name array or the size of a name eceed the limit.
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
  -- Raise ORA-24198: Invalid operation id.

  MEMBER FUNCTION get_names (id IN PLS_INTEGER)
  RETURN AQ$_JMS_NAMEARRAY,

--============================================
  -- Retrieve a portion of the names within the map message.
  -- Since aq$_jms_namearray has a size of 1024 and each element a varchar(200),
  -- this function raise error if either of sizes limit is exceeded.
  -- The index of map message starts from 0.
  --
  -- The function returns the number of names that has been retrieved.
  -- The names retrieved is the intersection of the interval [offset, offset+length-1]
  -- and interval [0, size-1] where size is the size of this map message.
  -- If the intersection is empty set, names will be NULL and the function returns 0
  -- as the number of names retrieved. These can be used as a test that there is
  -- no more name to read from the map message.
  --
  -- Parameters:
  --  id      - the operation id for this ADT instance.
  --  names   - the names that has been retrieved.
  --  offset  - the offset from which to start retrieving.
  --  length  - the length of the names to be retrieved.
  --
  -- Raise ORA-24195: size of the name array or the size of a name eceed the limit.
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
  -- Raise ORA-24198: Invalid operation id.

  MEMBER FUNCTION get_names (
         id       IN        PLS_INTEGER,
         names    OUT       AQ$_JMS_NAMEARRAY,
         offset   IN        PLS_INTEGER,
         length   IN        PLS_INTEGER )
  RETURN PLS_INTEGER,


  --============================================
  -- Test whether an item exists in the map message.
  -- Return TRUE if the item exists.
  --
  -- Parameters:
  --  id   - the operation id for this ADT instance.
  --  name - the specified name.
  --
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
  -- Raise ORA-24198: Invalid operation id.

  MEMBER FUNCTION item_exists (id IN PLS_INTEGER, name IN VARCHAR2)
  RETURN BOOLEAN,


  --============================================
  -- Read a object value from the map message.
  --
  -- The function returns a general value ADT AQ$_JMS_VALUE. User can use the
  -- "type" attribute of this ADT to interpret the data.
-- The following is a map among type attribute, JAVA type and value attributes
  --
  -- -----------------------------------------------------------------
  --               type                 | JAVA type | value attributes
  -- -----------------------------------------------------------------
  -- DBMS_JMS_PLSQL.DATA_TYPE_BYTE      |  byte     |    num_val
  -- -----------------------------------------------------------------
  -- DBMS_JMS_PLSQL.DATA_TYPE_SHORT     |  short    |    num_val
  -- -----------------------------------------------------------------
  -- DBMS_JMS_PLSQL.DATA_TYPE_INTEGER   |  int      |    num_val
  -- -----------------------------------------------------------------
  -- DBMS_JMS_PLSQL.DATA_TYPE_LONG      |  long     |    num_val
  -- -----------------------------------------------------------------
  -- DBMS_JMS_PLSQL.DATA_TYPE_FLOAT     |  float    |    num_val
  -- -----------------------------------------------------------------
  -- DBMS_JMS_PLSQL.DATA_TYPE_DOUBLE    |  double   |    num_val
  -- -----------------------------------------------------------------
  -- DBMS_JMS_PLSQL.DATA_TYPE_BOOLEAN   |  boolean  |    num_val
  -- -----------------------------------------------------------------
  -- DBMS_JMS_PLSQL.DATA_TYPE_CHARACTER |  char     |    char_val
  -- -----------------------------------------------------------------
  -- DBMS_JMS_PLSQL.DATA_TYPE_STRING    |  String   |    text_val
  -- -----------------------------------------------------------------
  -- DBMS_JMS_PLSQL.DATA_TYPE_BYTES     |  byte[]   |    bytes_val
  -- -----------------------------------------------------------------
  --
  -- The function returns NULL if there is no such item with the specified name.
  --
  -- Also note that this memeber procedure might bring additional overhead
  -- comparing to other "read" memeber procedures. It is used only if the user
  -- does not know the data type before hand, otherwise it is always a good idea
  -- to use a specific read member procedure.
  --
  -- Parameters:
  --  id    - the operation id for this ADT instance.
  --  name  - the specified name.
  --  value - the object that is read.
  --
  -- Raise ORA-24194: The type conversion between the type of real value and the expected type is invalid.
  --                  In this particular case, an object with unsupported type is read from the stream.
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
  -- Raise ORA-24198: Invalid operation id.

  MEMBER PROCEDURE get_object (id IN PLS_INTEGER, name IN VARCHAR2, value OUT NOCOPY AQ$_JMS_VALUE),
 --============================================
  -- Get a boolean value from the map message with the specified name.
  --
  -- The function returns NULL if there is no such item with the specified name.
  --
  -- Parameters:
  --  id   - the operation id for this ADT instance.
  --  name - the specified name.
  --
  -- Raise ORA-24194: The type conversion between the type of real value and the expected type is invalid.
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
  -- Raise ORA-24198: Invalid operation id.

  MEMBER FUNCTION get_boolean (id IN PLS_INTEGER, name IN VARCHAR2)
  RETURN BOOLEAN,


  --============================================
  -- Get a byte from the map message with the specified name.
  --
  -- The function guarantees that the returned value is in the JAVA byte value range.
  -- This also means if this value is issued with a set_byte function,
  -- there wont be an out of range error raised.
  --
  -- The function returns NULL if there is no such item with the specified name.
  --
  -- Parameters:
  --  id   - the operation id for this ADT instance.
  --  name - the specified name.
  --
  -- Raise ORA-24194: The type conversion between the type of real value and the expected type is invalid.
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
  -- Raise ORA-24198: Invalid operation id.

  MEMBER FUNCTION get_byte (id IN PLS_INTEGER, name IN VARCHAR2)
  RETURN PLS_INTEGER,


  --============================================
  -- Get a byte array from the map message with the specified name.
  --
  -- The function returns NULL if there is no such item with the specified name.
  --
  -- Parameters:
  --  id    - the operation id for this ADT instance.
  --  name  - the specified name.
  --  value - the bytes that is read.
  --
  -- Raise ORA-24194: The type conversion between the type of real value and the expected type is invalid.
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
-- Raise ORA-24198: Invalid operation id.

  MEMBER PROCEDURE get_bytes (id IN PLS_INTEGER, name IN VARCHAR2, value OUT NOCOPY BLOB),

  --============================================
  -- Get a char from the map message with the specified name.
  --
  -- The function returns NULL if there is no such item with the specified name.
  --
  -- Parameters:
  --  id   - the operation id for this ADT instance.
  --  name - the specified name.
  --
  -- Raise ORA-24194: The type conversion between the type of real value and the expected type is invalid.
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
  -- Raise ORA-24198: Invalid operation id.

  MEMBER FUNCTION get_char (id IN PLS_INTEGER, name IN VARCHAR2)
  RETURN CHAR,


  --============================================
  -- Get a double from the map message with the specified name.
  --
  -- The function returns NULL if there is no such item with the specified name.
  --
  -- Parameters:
  --  id   - the operation id for this ADT instance.
  --  name - the specified name.
  --
  -- Raise ORA-24194: The type conversion between the type of real value and the expected type is invalid.
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
  -- Raise ORA-24198: Invalid operation id.

  MEMBER FUNCTION get_double (id IN PLS_INTEGER, name IN VARCHAR2)
  RETURN DOUBLE PRECISION,

  --============================================
  -- Get a float from the map message with the specified name.
  --
  -- The function returns NULL if there is no such item with the specified name.
  --
  -- Parameters:
  --  id   - the operation id for this ADT instance.
  --  name - the specified name.
  --
  -- Raise ORA-24194: The type conversion between the type of real value and the expected type is invalid.
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
  -- Raise ORA-24198: Invalid operation id.
MEMBER FUNCTION get_float (id IN PLS_INTEGER, name IN VARCHAR2)
  RETURN FLOAT,


  --============================================
  -- Get a int from the map message with the specified name.
  --
  -- The function guarantees that the returned value is in the JAVA int value range.
  -- This also means if this value is issued with a set_int function,
  -- there wont be an out of range error raised.
  --
  -- The function returns NULL if there is no such item with the specified name.
  --
  -- Parameters:
  --  id   - the operation id for this ADT instance.
  --  name - the specified name.
  --
  -- Raise ORA-24194: The type conversion between the type of real value and the expected type is invalid.
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
  -- Raise ORA-24198: Invalid operation id.

  MEMBER FUNCTION get_int (id IN PLS_INTEGER, name IN VARCHAR2)
  RETURN PLS_INTEGER,


  --============================================
  -- Get a long from the map message with the specified name.
  --
  -- The function guarantees that the returned value is in the JAVA long value range.
  -- This also means if this value is issued with a set_long function,
  -- there wont be an out of range error raised.
  --
  -- The function returns NULL if there is no such item with the specified name.
  --
  -- Parameters:
  --  id   - the operation id for this ADT instance.
  --  name - the specified name.
  --
  -- Raise ORA-24194: The type conversion between the type of real value and the expected type is invalid.
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
  -- Raise ORA-24198: Invalid operation id.

  MEMBER FUNCTION get_long (id IN PLS_INTEGER, name IN VARCHAR2)
  RETURN NUMBER,


  --============================================
  -- Get a short from the map message with the specified name.
  --
  -- The function guarantees that the returned value is in the JAVA short value range.
  -- This also means if this value is issued with a set_short function,
  -- there wont be an out of range error raised.
  --
  -- The function returns NULL if there is no such item with the specified name.
  --
  -- Parameters:
  --  id   - the operation id for this ADT instance.
  --  name - the specified name.
  --
  -- Raise ORA-24194: The type conversion between the type of real value and the expected type is invalid.
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
  -- Raise ORA-24198: Invalid operation id.

  MEMBER FUNCTION get_short (id IN PLS_INTEGER, name IN VARCHAR2)
  RETURN PLS_INTEGER,

  --============================================
  -- Get a String from the map message with the specified name.
  --
  -- The function returns NULL if there is no such item with the specified name.
  --
  -- Parameters:
  --  id    - the operation id for this ADT instance.
  --  name  - the specified name.
  --  value - the string that is read.
  --
  -- Raise ORA-24194: The type conversion between the type of real value and the expected type is invalid.
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
  -- Raise ORA-24198: Invalid operation id.

  MEMBER PROCEDURE get_string (id IN PLS_INTEGER, name IN VARCHAR2, value OUT NOCOPY CLOB),


  --============================================
  -- Set a boolean to the map message with the specified name.
  --
  -- Parameters:
  --  id     - the operation id for this ADT instance.
  --  name   - the specified name.
  --  value  - the boolean value to be written. The value is copied into the map message.
  --
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
  -- Raise ORA-24198: Invalid operation id.

  MEMBER PROCEDURE set_boolean (id IN PLS_INTEGER, name IN VARCHAR2, value IN BOOLEAN),


  --============================================
  -- Set a byte to the map message with the specified name.
  --
  -- Parameters:
  --  id     - the operation id for this ADT instance.
--  name   - the specified name.
  --  value  - the byte value to be written. The value is copied into the map message.
  --
  -- Raise ORA-24193: The parameter value exceeds the valid JAVA type range.
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
  -- Raise ORA-24198: Invalid operation id.

  MEMBER PROCEDURE set_byte (id IN PLS_INTEGER, name IN VARCHAR2, value IN PLS_INTEGER),


  --============================================
  -- Set a byte array to the map message with the specified name.
  --
  -- This procedure takes a RAW type.
  --
  -- Parameters:
  --  id     - the operation id for this ADT instance.
  --  name   - the specified name.
  --  value  - the byte array value to be written. The value is copied into the map message.
  --
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
  -- Raise ORA-24198: Invalid operation id.

  MEMBER PROCEDURE set_bytes (id IN PLS_INTEGER, name IN VARCHAR2, value IN RAW),


  --============================================
  -- Set a byte array to the map message with the specified name.
  --
  -- This procedure takes a BLOB type.
  --
  -- Parameters:
  --  id     - the operation id for this ADT instance.
  --  name   - the specified name.
  --  value  - the byte array value to be written. The value is copied into the map message.
  --
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
  -- Raise ORA-24198: Invalid operation id.

  MEMBER PROCEDURE set_bytes (id IN PLS_INTEGER, name IN VARCHAR2, value IN BLOB),


  --============================================
  -- Set a portion of byte array to the map message with the specified name.
  --
  -- This procedure takes a RAW type.
  -- If the range [offset, offset+length] exceeds the boundary of the byte array value,
  -- a JAVA IndexOutOfBoundsException is thrown at the JAVA stored procedure and ORA-24197
  -- ora error is raised at the PL/SQL side. The index starts from 0.
  --
  -- Parameters:
  --  id     - the operation id for this ADT instance.
 --  name   - the specified name.
  --  value  - the byte array value to be written. The value is copied into the map message.
  --  offset - the initial offset within the byte array.
  --  length - the number of bytes to use
  --
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
  -- Raise ORA-24198: Invalid operation id.

  MEMBER PROCEDURE set_bytes (
         id        IN      PLS_INTEGER,
         name      IN      VARCHAR2,
         value     IN      RAW,
         offset    IN      PLS_INTEGER,
         length    IN      PLS_INTEGER
  ),


  --============================================
  -- Set a portion of byte array to the map message with the specified name.
  --
  -- This procedure takes a BLOB type.
  -- If the range [offset, offset+length] exceeds the boundary of the byte array value,
  -- a JAVA IndexOutOfBoundsException is thrown at the JAVA stored procedure and ORA-24197
  -- ora error is raised at the PL/SQL side. The index starts from 0.
  --
  -- Parameters:
  --  id     - the operation id for this ADT instance.
  --  name   - the specified name.
  --  value  - the byte array value to be written. The value is copied into the map message.
  --  offset - the initial offset within the byte array.
  --  length - the number of bytes to use
  --
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
  -- Raise ORA-24198: Invalid operation id.

  MEMBER PROCEDURE set_bytes (
         id        IN      PLS_INTEGER,
         name      IN      VARCHAR2,
         value     IN      BLOB,
         offset    IN      PLS_INTEGER,
         length    IN      PLS_INTEGER
  ),

  --============================================
  -- Set a char to the map message with the specified name.
  --
  -- Parameters:
  --  id     - the operation id for this ADT instance.
  --  name   - the specified name.
  --  value  - the char value to be written. The value is copied into the map message.
  --
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
  -- Raise ORA-24198: Invalid operation id.
  MEMBER PROCEDURE set_char (id IN PLS_INTEGER, name IN VARCHAR2, value IN CHAR),


  --============================================
  -- Set a double to the map message with the specified name.
  --
  -- Parameters:
  --  id     - the operation id for this ADT instance.
  --  name   - the specified name.
  --  value  - the double value to be written. The value is copied into the map message.
  --
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
  -- Raise ORA-24198: Invalid operation id.

  MEMBER PROCEDURE set_double (id IN PLS_INTEGER, name IN VARCHAR2, value IN DOUBLE PRECISION),


  --============================================
  -- Set a float to the map message with the specified name.
  --
  -- Parameters:
  --  id     - the operation id for this ADT instance.
  --  name   - the specified name.
  --  value  - the float value to be written. The value is copied into the map message.
  --
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
  -- Raise ORA-24198: Invalid operation id.

  MEMBER PROCEDURE set_float (id IN PLS_INTEGER, name IN VARCHAR2, value IN FLOAT),


  --============================================
  -- Set a int to the map message with the specified name.
  --
  -- Parameters:
  --  id     - the operation id for this ADT instance.
  --  name   - the specified name.
  --  value  - the int value to be written. The value is copied into the map message.
  --
  -- Raise ORA-24193: The parameter value exceeds the valid JAVA type range.
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
  -- Raise ORA-24198: Invalid operation id.

  MEMBER PROCEDURE set_int (id IN PLS_INTEGER, name IN VARCHAR2, value IN PLS_INTEGER),


  --============================================
  -- Set a long to the map message with the specified name.
  --
  -- Parameters:
  --  id     - the operation id for this ADT instance.
  --  name   - the specified name.
 --  value  - the long value to be written. The value is copied into the map message.
  --
  -- Raise ORA-24193: The parameter value exceeds the valid JAVA type range.
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
  -- Raise ORA-24198: Invalid operation id.

  MEMBER PROCEDURE set_long (id IN PLS_INTEGER, name IN VARCHAR2, value IN NUMBER),


  --============================================
  -- Set a short to the map message with the specified name.
  --
  -- Parameters:
  --  id     - the operation id for this ADT instance.
  --  name   - the specified name.
  --  value  - the short value to be written. The value is copied into the map message.
  --
  -- Raise ORA-24193: The parameter value exceeds the valid JAVA type range.
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
  -- Raise ORA-24198: Invalid operation id.

  MEMBER PROCEDURE set_short (id IN PLS_INTEGER, name IN VARCHAR2, value IN PLS_INTEGER),


  --============================================
  -- Set a String to the map message with the specified name.
  --
  -- This procedure takes VARCHAR2 type.
  --
  -- Parameters:
  --  id     - the operation id for this ADT instance.
  --  name   - the specified name.
  --  value  - the string value to be written. The value is copied into the map message.
  --
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
  -- Raise ORA-24198: Invalid operation id.

  MEMBER PROCEDURE set_string (id IN PLS_INTEGER, name IN VARCHAR2, value IN VARCHAR2),


  --============================================
  -- Set a String to the map message with the specified name.
  --
  -- This procedure takes CLOB type.
  --
  -- Parameters:
  --  id     - the operation id for this ADT instance.
  --  name   - the specified name.
  --  value  - the string value to be written. The value is copied into the map message.
  --
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
  -- Raise ORA-24198: Invalid operation id.
MEMBER PROCEDURE set_string (id IN PLS_INTEGER, name IN VARCHAR2, value IN CLOB),


  --*******************************************
  -- The following are JMS header related procedures
  --*******************************************

  MEMBER PROCEDURE set_replyto (replyto IN      sys.aq$_agent),

  MEMBER PROCEDURE set_type (type       IN      VARCHAR ),

  MEMBER PROCEDURE set_userid (userid   IN      VARCHAR ),

  MEMBER PROCEDURE set_appid (appid     IN      VARCHAR ),

  MEMBER PROCEDURE set_groupid (groupid IN      VARCHAR ),

  MEMBER PROCEDURE set_groupseq (groupseq       IN      int ),

  MEMBER PROCEDURE clear_properties ,

  MEMBER PROCEDURE set_boolean_property (
                property_name   IN      VARCHAR,
                property_value  IN      BOOLEAN ),

  MEMBER PROCEDURE set_byte_property (
                property_name   IN      VARCHAR,
                property_value  IN      int ),

  MEMBER PROCEDURE set_short_property (
                property_name   IN      VARCHAR,
                property_value  IN      int ),

  MEMBER PROCEDURE set_int_property (
                property_name   IN      VARCHAR,
                property_value  IN      int ),

  MEMBER PROCEDURE set_long_property (
                property_name   IN      VARCHAR,
                property_value  IN      NUMBER ),

  MEMBER PROCEDURE set_float_property (
                property_name   IN      VARCHAR,
                property_value  IN      FLOAT ),

  MEMBER PROCEDURE set_double_property (
                property_name   IN      VARCHAR,
                property_value  IN      DOUBLE PRECISION ),

  MEMBER PROCEDURE set_string_property (
                property_name   IN      VARCHAR,
                property_value  IN      VARCHAR ),
MEMBER FUNCTION get_replyto RETURN sys.aq$_agent,

  MEMBER FUNCTION get_type RETURN VARCHAR,

  MEMBER FUNCTION get_userid RETURN VARCHAR,

  MEMBER FUNCTION get_appid RETURN VARCHAR,

  MEMBER FUNCTION get_groupid RETURN VARCHAR,

  MEMBER FUNCTION get_groupseq RETURN int,

  MEMBER FUNCTION get_boolean_property ( property_name   IN      VARCHAR)
  RETURN   BOOLEAN,

  MEMBER FUNCTION get_byte_property ( property_name   IN      VARCHAR)
  RETURN   int,

  MEMBER FUNCTION get_short_property ( property_name   IN      VARCHAR)
  RETURN   int,

  MEMBER FUNCTION get_int_property ( property_name   IN      VARCHAR)
  RETURN   int,

  MEMBER FUNCTION get_long_property ( property_name   IN      VARCHAR)
  RETURN   NUMBER,

  MEMBER FUNCTION get_float_property ( property_name   IN      VARCHAR)
  RETURN   FLOAT,

  MEMBER FUNCTION get_double_property ( property_name   IN      VARCHAR)
  RETURN   DOUBLE PRECISION,

  MEMBER FUNCTION get_string_property ( property_name   IN      VARCHAR)
  RETURN   VARCHAR


);
/

