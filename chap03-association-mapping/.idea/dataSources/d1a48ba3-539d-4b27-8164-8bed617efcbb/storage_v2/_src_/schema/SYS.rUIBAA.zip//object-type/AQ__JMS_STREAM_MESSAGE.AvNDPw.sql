create type aq$_jms_stream_message
                                       authid current_user
as object
(
  header     aq$_jms_header,
  bytes_len  int,
  bytes_raw  raw(2000),
  bytes_lob  blob,
  --============================================
  STATIC FUNCTION construct RETURN aq$_jms_stream_message,


  -- *******************************************
  -- The following are common procedures of aq$_jms_stream_message,
  -- aq$_jms_bytes_message and aq$_jms_map_message types to synchronize
  -- the data between JAVA stored procedure and PL/SQL.
  -- *******************************************

  --============================================
  -- Get the JAVA exception thrown during the previous failure.
  -- Only one JAVA exception is recorded for a session. If the
  -- exception is not fetched in time, it might be overwritten
  -- by the exception thrown in next failure.

  STATIC FUNCTION get_exception
  RETURN AQ$_JMS_EXCEPTION,


  --============================================
  -- Clean all the messages in the JVM session memory.
  --

  STATIC PROCEDURE clean_all,


  --============================================
  -- Populate the data at JAVA stored procedure with the data at PL/SQL side.
  --
  -- Underlying, it takes the RAW/BLOB stored in PL/SQL aq$_jms_stream_message
  -- to construct a JAVA object (for aq$_jms_stream_message is ObjectInputStream)
  -- which is stored in ORACLE JVM session memeory.
  --
  -- Parameter "id" is called operation id that is used to identify the slot
  -- where the JAVA object is stored in the ORACLE JVM session memeory.
  -- If "id" is NULL, a new slot is created for this PL/SQL object.
  -- Later JMS operations on the payload need to provide this operation id.
  --
  -- Parameters:
  --  id  - the operation id for this ADT instance.
  --        if id is negative, the system will create a new operation id.
  --
  -- Returns:
  --  the operation id.
  --
  -- The prepare procedure for aq$_jms_stream_message sets the message access mode
  -- to MESSAGE_ACCESS_READONLY. Later calls of write_XXX procedure raise ORA-24196 error.
  -- User can call clear_body procedure to set the message access mode to
  -- MESSAGE_ACCESS_WRITEONLY.
  --
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
  -- Raise ORA-24198: Invalid operation id.
-- Raise ORA-24199: JAVA store procedure message store overflow.

  MEMBER FUNCTION prepare (id IN PLS_INTEGER)
  RETURN PLS_INTEGER,


  --============================================
  -- Set the data at JAVA stored procedure as empty payload.
  --
  -- Underlying, it initialize an new ObjectOutputStream object and set it to
  -- the static varaible in ORACLE JVM session memeory.
  --
  -- Parameter "id" is called operation id that is used to identify the slot
  -- where the JAVA object is stored in the ORACLE JVM session memeory.
  -- If "id" is NULL, a new slot is created for this PL/SQL object.
  -- Later JMS operations on the payload need to provide this operation id.
  --
  -- Parameters:
  --  id  - the operation id for this ADT instance.
  --        if id is negative, the system will create a new operation id.
  --
  -- Returns:
  --  the operation id.
  --
  -- The clear_body procedure for aq$_jms_stream_message sets the message access mode
  -- to MESSAGE_ACCESS_WRITEONLY. Later calls of read_XXX procedure raise ORA-24196 error.
  -- User can call reset procedure or prepare procedure to set the message access mode
  -- to MESSAGE_ACCESS_READONLY. Note the difference between prepare procedure and
  -- reset procedure.
  --
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
  -- Raise ORA-24198: Invalid operation id.
  -- Raise ORA-24199: JAVA store procedure message store overflow.

  MEMBER FUNCTION clear_body (id IN PLS_INTEGER)
  RETURN PLS_INTEGER,


  --============================================
  -- Get the current message access mode of this message
  -- The result will be either dbms_aqjms.MESSAGE_ACCESS_WRITEONLY or
  -- dbms_aqjms.MESSAGE_ACCESS_READONLY.
  --
  -- Parameters:
  --  id  - the operation id for this ADT instance.
  --
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
  -- Raise ORA-24198: Invalid operation id.

  MEMBER FUNCTION get_mode (id IN PLS_INTEGER)
  RETURN PLS_INTEGER,

  --============================================
  -- Reset reposition the stream to the begining for reading.
  --
  -- Parameters:
  --  id  - the operation id for this ADT instance.
  --
  -- The reset procedure for aq$_jms_stream_message sets the message access mode
  -- to MESSAGE_ACCESS_READONLY. Later calls of write_XXX procedure raise ORA-24196 error.
  -- User can call clear_body procedure to set the message access mode to
  -- MESSAGE_ACCESS_WRITEONLY.
  --
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
  -- Raise ORA-24198: Invalid operation id.

  MEMBER PROCEDURE reset (id IN PLS_INTEGER),


  --============================================
  -- Flush the data at JAVA stored procedure side to PL/SQL side.
  --
  -- Underlying, it update the data at PL/SQL side to the payload stored at
  -- the JAVA stored procedure side.
  --
  -- The flush procedure for aq$_jms_stream_message does not affect current message access
  -- mode. User can continue to call procedures appropriate to the current mode.
  --
  -- Parameters:
  --  id  - the operation id for this ADT instance.
  --
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
  -- Raise ORA-24198: Invalid operation id.

  MEMBER PROCEDURE flush (id IN PLS_INTEGER),


  --============================================
  -- clean the data at JAVA stored procedure side to PL/SQL side.
  --
  -- Underlying, it close and clean upthe ObjectInputStream or ObjectOutputStream
  -- at the JAVA stored procedure side corresponding to the operation id.
  -- It is very import to call this procedure to avoid memeory leak!
  --
  -- Parameters:
  --  id  - the operation id for this ADT instance.
  --
  -- Raise ORA-24198: Invalid operation id.

  MEMBER PROCEDURE clean (id IN PLS_INTEGER),


  --*******************************************
 -- JMS operations member functions and procedures
  --*******************************************

  --============================================
  -- Read a object value from the stream message.
  --
  -- The function returns a general value ADT AQ$_JMS_VALUE. User can use the
  -- "type" attribute of this ADT to interpret the data.
  -- The following is a map among type attribute, JAVA type and value attributes
  --
  -- -----------------------------------------------------------------
  --               type                 | JAVA type | value attributes
  -- -----------------------------------------------------------------
  -- DBMS_JMS_PLSQL.DATA_TYPE_BYTE      |  byte     |    num_val
  -- -----------------------------------------------------------------
  -- DBMS_JMS_PLSQL.DATA_TYPE_SHORT     |  short    |    num_val
  -- -----------------------------------------------------------------
  -- DBMS_JMS_PLSQL.DATA_TYPE_INTEGER   |  int      |    num_val
  -- -----------------------------------------------------------------
  -- DBMS_JMS_PLSQL.DATA_TYPE_LONG      |  long     |    num_val
  -- -----------------------------------------------------------------
  -- DBMS_JMS_PLSQL.DATA_TYPE_FLOAT     |  float    |    num_val
  -- -----------------------------------------------------------------
  -- DBMS_JMS_PLSQL.DATA_TYPE_DOUBLE    |  double   |    num_val
  -- -----------------------------------------------------------------
  -- DBMS_JMS_PLSQL.DATA_TYPE_BOOLEAN   |  boolean  |    num_val
  -- -----------------------------------------------------------------
  -- DBMS_JMS_PLSQL.DATA_TYPE_CHARACTER |  char     |    char_val
  -- -----------------------------------------------------------------
  -- DBMS_JMS_PLSQL.DATA_TYPE_STRING    |  String   |    text_val
  -- -----------------------------------------------------------------
  -- DBMS_JMS_PLSQL.DATA_TYPE_BYTES     |  byte[]   |    bytes_val
  -- -----------------------------------------------------------------
  --
  -- The function returns NULL if the end of the message stream has been reached.
  --
  -- Also note that this memeber procedure might bring additional overhead
  -- comparing to other "read" memeber procedures. It is used only if the user
  -- does not know the data type before hand, otherwise it is always a good idea
  -- to use a specific read member procedure.
  --
  -- Parameters:
  --  id    - the operation id for this ADT instance.
  --  value - the object that is read.
  --
  -- Raise ORA-24194: The type conversion between the type of real value and the expected type is invalid.
  --                  In this particular case, an object with unsupported type is read from the stream.
  -- Raise ORA-24196: The stream message is in write-only mode.
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
-- Raise ORA-24198: Invalid operation id.

  MEMBER PROCEDURE read_object (id IN PLS_INTEGER, value OUT NOCOPY AQ$_JMS_VALUE),


  --============================================
  -- Read a boolean value from the stream message.
  --
  -- The function returns NULL if the end of the message stream has been reached.
  --
  -- Parameters:
  --  id  - the operation id for this ADT instance.
  --
  -- Raise ORA-24194: The type conversion between the type of real value and the expected type is invalid.
  -- Raise ORA-24196: The stream message is in write-only mode.
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
  -- Raise ORA-24198: Invalid operation id.

  MEMBER FUNCTION read_boolean (id IN PLS_INTEGER)
  RETURN BOOLEAN,


  --============================================
  -- Read a byte from the stream message.
  --
  -- The function guarantees that the returned value is in the JAVA byte value range.
  -- This also means if this value is issued with a write_byte function,
  -- there wont be an out of range error raised.
  --
  -- The function returns NULL if the end of the message stream has been reached.
  --
  -- Parameters:
  --  id  - the operation id for this ADT instance.
  --
  -- Raise ORA-24194: The type conversion between the type of real value and the expected type is invalid.
  -- Raise ORA-24196: The stream message is in write-only mode.
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
  -- Raise ORA-24198: Invalid operation id.

  MEMBER FUNCTION read_byte (id IN PLS_INTEGER)
  RETURN PLS_INTEGER,


  --============================================
  -- Read a byte array from the stream message.
  --
  -- The function returns NULL if the end of the message stream has been reached.
  --
  -- Parameters:
 --  id    - the operation id for this ADT instance.
  --  value - the bytes that is read.
  --
  -- Raise ORA-24194: The type conversion between the type of real value and the expected type is invalid.
  -- Raise ORA-24196: The stream message is in write-only mode.
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
  -- Raise ORA-24198: Invalid operation id.

  MEMBER PROCEDURE read_bytes (id IN PLS_INTEGER, value OUT NOCOPY BLOB),


  --============================================
  -- Read a char from the stream message.
  --
  -- The function returns NULL if the end of the message stream has been reached.
  --
  -- Parameters:
  --  id  - the operation id for this ADT instance.
  --
  -- Raise ORA-24194: The type conversion between the type of real value and the expected type is invalid.
  -- Raise ORA-24196: The stream message is in write-only mode.
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
  -- Raise ORA-24198: Invalid operation id.

  MEMBER FUNCTION read_char (id IN PLS_INTEGER)
  RETURN CHAR,


  --============================================
  -- Read a double from the stream message.
  --
  -- The function returns NULL if the end of the message stream has been reached.
  --
  -- Parameters:
  --  id  - the operation id for this ADT instance.
  --
  -- Raise ORA-24194: The type conversion between the type of real value and the expected type is invalid.
  -- Raise ORA-24196: The stream message is in write-only mode.
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
  -- Raise ORA-24198: Invalid operation id.

  MEMBER FUNCTION read_double (id IN PLS_INTEGER)
  RETURN DOUBLE PRECISION,

  --============================================
  -- Read a float from the stream message.
  --
  -- The function returns NULL if the end of the message stream has been reached.
--
  -- Parameters:
  --  id  - the operation id for this ADT instance.
  --
  -- Raise ORA-24194: The type conversion between the type of real value and the expected type is invalid.
  -- Raise ORA-24196: The stream message is in write-only mode.
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
  -- Raise ORA-24198: Invalid operation id.

  MEMBER FUNCTION read_float (id IN PLS_INTEGER)
  RETURN FLOAT,


  --============================================
  -- Read a int from the stream message.
  --
  -- The function guarantees that the returned value is in the JAVA int value range.
  -- This also means if this value is issued with a write_int function,
  -- there wont be an out of range error raised.
  --
  -- The function returns NULL if the end of the message stream has been reached.
  --
  -- Parameters:
  --  id  - the operation id for this ADT instance.
  --
  -- Raise ORA-24194: The type conversion between the type of real value and the expected type is invalid.
  -- Raise ORA-24196: The stream message is in write-only mode.
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
  -- Raise ORA-24198: Invalid operation id.

  MEMBER FUNCTION read_int (id IN PLS_INTEGER)
  RETURN PLS_INTEGER,


  --============================================
  -- Read a long from the stream message.
  --
  -- The function guarantees that the returned value is in the JAVA long value range.
  -- This also means if this value is issued with a write_long function,
  -- there wont be an out of range error raised.
  --
  -- The function returns NULL if the end of the message stream has been reached.
  --
  -- Parameters:
  --  id  - the operation id for this ADT instance.
  --
  -- Raise ORA-24194: The type conversion between the type of real value and the expected type is invalid.
  -- Raise ORA-24196: The stream message is in write-only mode.
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
-- Raise ORA-24198: Invalid operation id.

  MEMBER FUNCTION read_long (id IN PLS_INTEGER)
  RETURN NUMBER,


  --============================================
  -- Read a short from the stream message.
  --
  -- The function guarantees that the returned value is in the JAVA short value range.
  -- This also means if this value is issued with a write_short function,
  -- there wont be an out of range error raised.
  --
  -- The function returns NULL if the end of the message stream has been reached.
  --
  -- Parameters:
  --  id  - the operation id for this ADT instance.
  --
  -- Raise ORA-24194: The type conversion between the type of real value and the expected type is invalid.
  -- Raise ORA-24196: The stream message is in write-only mode.
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
  -- Raise ORA-24198: Invalid operation id.

  MEMBER FUNCTION read_short (id IN PLS_INTEGER)
  RETURN PLS_INTEGER,

  --============================================
  -- Read a String from the stream message.
  --
  -- The function returns NULL if the end of the message stream has been reached.
  --
  -- Parameters:
  --  id    - the operation id for this ADT instance.
  --  value - the string that is read.
  --
  -- Raise ORA-24194: The type conversion between the type of real value and the expected type is invalid.
  -- Raise ORA-24196: The stream message is in write-only mode.
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
  -- Raise ORA-24198: Invalid operation id.

  MEMBER PROCEDURE read_string (id IN PLS_INTEGER, value OUT NOCOPY CLOB),


  --============================================
  -- Write a boolean to the stream message.
  --
  -- Parameters:
  --  id     - the operation id for this ADT instance.
  --  value  - the boolean value to be written. The value is copied into the stream message.
--
  -- Raise ORA-24196: The stream message is in read-only mode.
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
  -- Raise ORA-24198: Invalid operation id.

  MEMBER PROCEDURE write_boolean (id IN PLS_INTEGER, value IN BOOLEAN),


  --============================================
  -- Write a byte to the stream message.
  --
  -- Parameters:
  --  id     - the operation id for this ADT instance.
  --  value  - the byte value to be written. The value is copied into the stream message.
  --
  -- Raise ORA-24193: The parameter value exceeds the valid JAVA type range.
  -- Raise ORA-24196: The stream message is in read-only mode.
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
  -- Raise ORA-24198: Invalid operation id.

  MEMBER PROCEDURE write_byte (id IN PLS_INTEGER, value IN PLS_INTEGER),


  --============================================
  -- Write a byte array to the stream message.
  --
  -- This procedure takes a RAW type.
  -- Note that two consecutively written byte arrays are read as two distinct fields.
  --
  -- Parameters:
  --  id     - the operation id for this ADT instance.
  --  value  - the byte array value to be written. The value is copied into the stream message.
  --
  -- Raise ORA-24196: The stream message is in read-only mode.
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
  -- Raise ORA-24198: Invalid operation id.

  MEMBER PROCEDURE write_bytes (id IN PLS_INTEGER, value IN RAW),


  --============================================
  -- Write a byte array to the stream message.
  --
  -- This procedure takes a BLOB type.
  -- Note that two consecutively written byte arrays are read as two distinct fields.
  --
  -- Parameters:
  --  id     - the operation id for this ADT instance.
 --  value  - the byte array value to be written. The value is copied into the stream message.
  --
  -- Raise ORA-24196: The stream message is in read-only mode.
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
  -- Raise ORA-24198: Invalid operation id.

  MEMBER PROCEDURE write_bytes (id IN PLS_INTEGER, value IN BLOB),


  --============================================
  -- Write a portion of byte array to the stream message.
  --
  -- This procedure takes a RAW type.
  -- Note that two consecutively written byte arrays are read as two distinct fields.
  -- If the range [offset, offset+length] exceeds the boundary of the byte array value,
  -- a JAVA IndexOutOfBoundsException is thrown at the JAVA stored procedure and ORA-24197
  -- ora error is raised at the PL/SQL side. The index starts from 0.
  --
  -- Parameters:
  --  id     - the operation id for this ADT instance.
  --  value  - the byte array value to be written. The value is copied into the stream message.
  --  offset - the initial offset within the byte array.
  --  length - the number of bytes to use
  --
  -- Raise ORA-24196: The stream message is in read-only mode.
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
  -- Raise ORA-24198: Invalid operation id.

  MEMBER PROCEDURE write_bytes (
         id        IN      PLS_INTEGER,
         value     IN      RAW,
         offset    IN      PLS_INTEGER,
         length    IN      PLS_INTEGER
  ),


  --============================================
  -- Write a portion of byte array to the stream message.
  --
  -- This procedure takes a BLOB type.
  -- Note that two consecutively written byte arrays are read as two distinct fields.
  -- If the range [offset, offset+length] exceeds the boundary of the byte array value,
  -- a JAVA IndexOutOfBoundsException is thrown at the JAVA stored procedure and ORA-24197
  -- ora error is raised at the PL/SQL side. The index starts from 0.
  --
  -- Parameters:
  --  id     - the operation id for this ADT instance.
  --  value  - the byte array value to be written. The value is copied into the stream message.
  --  offset - the initial offset within the byte array.
  --  length - the number of bytes to use
--
  -- Raise ORA-24196: The stream message is in read-only mode.
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
  -- Raise ORA-24198: Invalid operation id.

  MEMBER PROCEDURE write_bytes (
         id        IN      PLS_INTEGER,
         value     IN      BLOB,
         offset    IN      PLS_INTEGER,
         length    IN      PLS_INTEGER
  ),

  --============================================
  -- Write a char to the stream message.
  --
  -- Parameters:
  --  id     - the operation id for this ADT instance.
  --  value  - the char value to be written. The value is copied into the stream message.
  --
  -- Raise ORA-24196: The stream message is in read-only mode.
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
  -- Raise ORA-24198: Invalid operation id.

  MEMBER PROCEDURE write_char (id IN PLS_INTEGER, value IN CHAR),


  --============================================
  -- Write a double to the stream message.
  --
  -- Parameters:
  --  id     - the operation id for this ADT instance.
  --  value  - the double value to be written. The value is copied into the stream message.
  --
  -- Raise ORA-24196: The stream message is in read-only mode.
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
  -- Raise ORA-24198: Invalid operation id.

  MEMBER PROCEDURE write_double (id IN PLS_INTEGER, value IN DOUBLE PRECISION),


  --============================================
  -- Write a float to the stream message.
  --
  -- Parameters:
  --  id     - the operation id for this ADT instance.
  --  value  - the float value to be written. The value is copied into the stream message.
  --
  -- Raise ORA-24196: The stream message is in read-only mode.
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
  -- Raise ORA-24198: Invalid operation id.
MEMBER PROCEDURE write_float (id IN PLS_INTEGER, value IN FLOAT),


  --============================================
  -- Write a int to the stream message.
  --
  -- Parameters:
  --  id     - the operation id for this ADT instance.
  --  value  - the int value to be written. The value is copied into the stream message.
  --
  -- Raise ORA-24193: The parameter value exceeds the valid JAVA type range.
  -- Raise ORA-24196: The stream message is in read-only mode.
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
  -- Raise ORA-24198: Invalid operation id.

  MEMBER PROCEDURE write_int (id IN PLS_INTEGER, value IN PLS_INTEGER),


  --============================================
  -- Write a long to the stream message.
  --
  -- Parameters:
  --  id     - the operation id for this ADT instance.
  --  value  - the long value to be written. The value is copied into the stream message.
  --
  -- Raise ORA-24193: The parameter value exceeds the valid JAVA type range.
  -- Raise ORA-24196: The stream message is in read-only mode.
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
  -- Raise ORA-24198: Invalid operation id.

  MEMBER PROCEDURE write_long (id IN PLS_INTEGER, value IN NUMBER),


  --============================================
  -- Write a short to the stream message.
  --
  -- Parameters:
  --  id     - the operation id for this ADT instance.
  --  value  - the short value to be written. The value is copied into the stream message.
  --
  -- Raise ORA-24193: The parameter value exceeds the valid JAVA type range.
  -- Raise ORA-24196: The stream message is in read-only mode.
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
  -- Raise ORA-24198: Invalid operation id.

  MEMBER PROCEDURE write_short (id IN PLS_INTEGER, value IN PLS_INTEGER),


  --============================================
  -- Write a String to the stream message.
  --
  -- This procedure takes VARCHAR2 type.
--
  -- Parameters:
  --  id     - the operation id for this ADT instance.
  --  value  - the string value to be written. The value is copied into the stream message.
  --
  -- Raise ORA-24196: The stream message is in read-only mode.
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
  -- Raise ORA-24198: Invalid operation id.

  MEMBER PROCEDURE write_string (id IN PLS_INTEGER, value IN VARCHAR2),


  --============================================
  -- Write a String to the stream message.
  --
  -- This procedure takes CLOB type.
  --
  -- Parameters:
  --  id     - the operation id for this ADT instance.
  --  value  - the string value to be written. The value is copied into the stream message.
  --
  -- Raise ORA-24196: The stream message is in read-only mode.
  -- Raise ORA-24197: JAVA stored procedure throws Exception during execution.
  -- Raise ORA-24198: Invalid operation id.

  MEMBER PROCEDURE write_string (id IN PLS_INTEGER, value IN CLOB),


  --*******************************************
  -- The following are JMS header related procedures
  --*******************************************

  MEMBER PROCEDURE set_replyto (replyto IN      sys.aq$_agent),

  MEMBER PROCEDURE set_type (type       IN      VARCHAR ),

  MEMBER PROCEDURE set_userid (userid   IN      VARCHAR ),

  MEMBER PROCEDURE set_appid (appid     IN      VARCHAR ),

  MEMBER PROCEDURE set_groupid (groupid IN      VARCHAR ),

  MEMBER PROCEDURE set_groupseq (groupseq       IN      int ),

  MEMBER PROCEDURE clear_properties ,

  MEMBER PROCEDURE set_boolean_property (
                property_name   IN      VARCHAR,
                property_value  IN      BOOLEAN ),

  MEMBER PROCEDURE set_byte_property (
                property_name   IN      VARCHAR,
                property_value  IN      int ),
  MEMBER PROCEDURE set_short_property (
                property_name   IN      VARCHAR,
                property_value  IN      int ),

  MEMBER PROCEDURE set_int_property (
                property_name   IN      VARCHAR,
                property_value  IN      int ),

  MEMBER PROCEDURE set_long_property (
                property_name   IN      VARCHAR,
                property_value  IN      NUMBER ),

  MEMBER PROCEDURE set_float_property (
                property_name   IN      VARCHAR,
                property_value  IN      FLOAT ),

  MEMBER PROCEDURE set_double_property (
                property_name   IN      VARCHAR,
                property_value  IN      DOUBLE PRECISION ),

  MEMBER PROCEDURE set_string_property (
                property_name   IN      VARCHAR,
                property_value  IN      VARCHAR ),

  MEMBER FUNCTION get_replyto RETURN sys.aq$_agent,

  MEMBER FUNCTION get_type RETURN VARCHAR,

  MEMBER FUNCTION get_userid RETURN VARCHAR,

  MEMBER FUNCTION get_appid RETURN VARCHAR,

  MEMBER FUNCTION get_groupid RETURN VARCHAR,

  MEMBER FUNCTION get_groupseq RETURN int,

  MEMBER FUNCTION get_boolean_property ( property_name   IN      VARCHAR)
  RETURN   BOOLEAN,

  MEMBER FUNCTION get_byte_property ( property_name   IN      VARCHAR)
  RETURN   int,

  MEMBER FUNCTION get_short_property ( property_name   IN      VARCHAR)
  RETURN   int,

  MEMBER FUNCTION get_int_property ( property_name   IN      VARCHAR)
  RETURN   int,

  MEMBER FUNCTION get_long_property ( property_name   IN      VARCHAR)
  RETURN   NUMBER,

  MEMBER FUNCTION get_float_property ( property_name   IN      VARCHAR)
RETURN   FLOAT,

  MEMBER FUNCTION get_double_property ( property_name   IN      VARCHAR)
  RETURN   DOUBLE PRECISION,

  MEMBER FUNCTION get_string_property ( property_name   IN      VARCHAR)
  RETURN   VARCHAR

);
/

