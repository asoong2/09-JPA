create procedure DBMS_FEATURE_IDH
    (feature_boolean  OUT  NUMBER,
     aux_count        OUT  NUMBER,
     feature_info     OUT  CLOB)
AS
  feature_usage          varchar2(1000);
  cursor c1 is select grantee,granted_role
                      from dba_role_privs where
                      granted_role = 'DBHADOOP' and grantee != 'SYS';
begin
  -- initialize
  aux_count := 0;
  feature_boolean := 0;
  feature_info := to_clob('In-Database Hadoop usage not detected');
  feature_usage := '';

  for i in c1
  loop
    aux_count := aux_count + 1;
  end loop;

  if aux_count > 0
  then
    feature_boolean := 1;
    feature_usage := feature_usage||':DBHADOOP users:'||aux_count;
    feature_info := to_clob(feature_usage);
  end if;

end;
/

