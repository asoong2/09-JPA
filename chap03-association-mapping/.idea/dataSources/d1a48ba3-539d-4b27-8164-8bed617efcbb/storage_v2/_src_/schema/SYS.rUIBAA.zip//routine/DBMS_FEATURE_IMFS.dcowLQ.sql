create procedure DBMS_FEATURE_IMFS (
    feature_boolean OUT NUMBER,
    aux_count       OUT NUMBER,
    feature_info    OUT CLOB)
as
  val       varchar2(4096);     -- FS status
  tbs       varchar2(4096);     -- FS tablespace name
  spspace   number;             -- space used by savepoints
  spcnttot  number;             -- total number of savepoints processed by FS
BEGIN
  select value into val from SYSDBIMFS_METADATA$ where key='STATUS';
  if( val = 'ENABLE' ) then
    feature_boolean := 1;

    -- Get FS assigned tbs
    select name into tbs
    from
      v$tablespace vtbs,
      (select to_number(value) as tsn from SYSDBIMFS_METADATA$ where key='TSN') t2
    where t2.tsn = vtbs.ts#;

    -- Get the number of CU persisted in FS.
    select count(*) into aux_count from SYS.SYSDBIMFS$;

    -- Get FS savepoint space usage.  Table is not created until feature is enabled
    -- so we need to do exec immediate.
    execute immediate 'select sum(dbms_lob.getlength(data)) from SYSDBIMFSDATA$'
      into spspace;

    -- Get total number of CU cached in FS
    select max(cuid) into spcnttot from sys.sysdbimfs$;

    feature_info := to_clob('In-Memory FastStart enabled on ' || tbs ||
                            ': Current Number of Savepoints in FastStart Area: ' || aux_count ||
                            ', Current Space Usage: ' || spspace ||
                            ', Total Number of Savepoints in FastStart Area: ' || spcnttot);
  else
    feature_boolean := 0;
    aux_count := 0;
    feature_info := to_clob('In-Memory FastStart Not Used');
  end if;
END DBMS_FEATURE_IMFS;
/

