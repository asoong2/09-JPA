create package body     CDBView is

function isLegalOwnerViewName(owner IN varchar2, oldview IN varchar2,
                              newview IN varchar2) return varchar2;
-- Create the cdb view
-- private helper procedure to create the cdb view
-- Note that quotes should not be added around owner, oldview_name and
-- newview_name before create_cdbview is invoked since all three are used
-- as literals to query dictionary views.
procedure create_cdbview(chk_upgrd IN boolean, owner IN varchar2,
                         oldview_name IN varchar2, newview_name IN varchar2) as
  sqlstmt        varchar2(4000);
  col_name       varchar2(128);
  comments       varchar2(4000);
  col_type       number;
  newview        varchar2(128);
  quoted_owner   varchar2(130); -- 2 more than size of owner
  quoted_oldview varchar2(130); -- 2 more than size of oldview_name
  quoted_newview varchar2(130); -- 2 more than size of newview_name
  unsupp_col_condition varchar2(4000);
  colcomments          varchar2(4000);
  unsupp_col_count     number;
  colcommentscur       SYS_REFCURSOR;
  table_not_found      EXCEPTION;
  PRAGMA               exception_init(table_not_found, -942);


  cursor tblcommentscur is select c.comment$
                from sys.obj$ o, sys.user$ u, sys.com$ c
                where o.name = oldview_name and u.name = owner
                and o.obj# = c.obj# and o.owner#=u.user#
                and (o.type# = 4 or o.type# = 2)
                and c.col# is null;

begin

  newview := isLegalOwnerViewName(owner, oldview_name, newview_name);
  if (newview is NULL) then
    RAISE table_not_found;
  end if;

  quoted_owner   := '"' || owner               || '"';
  quoted_oldview := '"' || oldview_name  || '"';
  quoted_newview := '"' || newview       || '"';

  -- Create cdb view
  sqlstmt := 'CREATE OR REPLACE VIEW ' ||
     quoted_owner || '.' || quoted_newview ||
     ' CONTAINER_DATA AS' ||
     ' SELECT k.*, k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG' ||
     ' FROM CONTAINERS(' || quoted_owner || '.' || quoted_oldview || ') k';

  execute immediate sqlstmt;

  -- table and column comments
  open tblcommentscur;
  fetch tblcommentscur into comments;
  comments := replace(comments, '''','''''');
  sqlstmt := 'comment on table ' || quoted_owner || '.' || quoted_newview ||
              ' is ''' || comments || ' in all containers''';
  execute immediate sqlstmt;
  close tblcommentscur;

  sqlstmt := 'comment on column ' || quoted_owner || '.' || quoted_newview ||
             '.CON_ID is ''container id''';
  execute immediate sqlstmt;

  sqlstmt := 'comment on column ' || quoted_owner || '.' || quoted_newview ||
             '.CON$NAME is ''Container Name''';
  execute immediate sqlstmt;

  sqlstmt := 'comment on column ' || quoted_owner || '.' || quoted_newview ||
             '.CDB$NAME is ''Database Name''';
  execute immediate sqlstmt;

  sqlstmt := 'comment on column ' || quoted_owner || '.' || quoted_newview ||
             '.CON$ERRNUM is ''Error Number''';
  execute immediate sqlstmt;

  sqlstmt := 'comment on column ' || quoted_owner || '.' || quoted_newview ||
             '.CON$ERRMSG is ''Error Message''';
  execute immediate sqlstmt;

  colcomments := 'select c.name, co.comment$ ' ||
                 'from sys.obj$ o, sys.col$ c, sys.user$ u, sys.com$ co ' ||
                 'where o.name = :1 ' ||
                 'and u.name = :2 ' ||
                 'and o.owner# = u.user# and (o.type# = 4 or o.type# = 2) ' ||
                 'and o.obj# = c.obj# ' ||
                 'and c.obj# = co.obj# and c.intcol# = co.col# ' ||
                 -- skip hidden column
                 'and bitand(c.property, 32) = 0 '||
                 -- skip null comment
                 'and co.comment$ is not null';
                          -- skip Long, Nested Table, Varray columns
  unsupp_col_condition := 'c.type# = 8 or c.type# = 122 or c.type# = 123 ' ||
                          -- skip ADT and REF columns
                          'or c.type# = 121 or c.type# = 111 ' ||
                          -- Bug 20683085: skip Opaque Type column except
                          -- xmltype stored as LOB. Check xmltype as lob using
                          -- property bit KQLDCOP2_XSLB.
		          -- Bug 23083309: if there are unsupported columns,
                          -- then XMLType column is skipped (hidden XMLType lob
                          -- column is already handled)
                          'or (c.type# = 58 and ' ||
                              '((bitand(c.property, ' ||
                                'power(2,32)*4194304)<>power(2,32)*4194304) '||
                                'or :3 > 0)) ' ||
                          -- Bug 21785587: skip long raw
                          'or c.type# = 24';

  sqlstmt := colcomments || ' and (' || unsupp_col_condition || ')';

  unsupp_col_count := 0;
  EXECUTE IMMEDIATE 'SELECT COUNT(*) FROM (' || sqlstmt ||')'
    INTO unsupp_col_count USING oldview_name, owner, unsupp_col_count;

  open colcommentscur for colcomments ||' and not ('||
                            unsupp_col_condition ||')'
                      USING oldview_name, owner, unsupp_col_count;
  loop
    fetch colcommentscur into col_name, comments;
    exit when colcommentscur%NOTFOUND;

    comments := replace(comments, '''','''''');
    sqlstmt := 'comment on column ' ||
               quoted_owner || '.' || quoted_newview || '.' ||
               col_name || ' is ''' || comments || '''';

    execute immediate sqlstmt;
  end loop;
  close colcommentscur;
end;

  function getlong(opcode in number, p_rowid in rowid) return varchar2
  as
      tablename dbms_id;
      colname   dbms_id;
      stmt      varchar2(400);
      retval    varchar2(4000);
  begin
      if (opcode = 1) then
        tablename := 'SYS.VIEW$';
        colname   := 'TEXT';
      elsif (opcode = 2) then
        tablename := 'SYS.CDEF$';
        colname   := 'CONDITION';
      else
        return NULL;
      end if;

      stmt := 'SELECT ' || colname || ' FROM ' || tablename ||
              ' WHERE ROWID = :1';
      CDBView_internal.long2varchar2_i(stmt, p_rowid, retval);
      return retval;
  end getlong;

  -- This function is created to prevent SQL injection. We couldn't use
  -- dbms_assert because catcdbviews.sql is called before dbms_assert
  -- is created
  function isLegalOwnerViewName(owner IN varchar2, oldview IN varchar2,
                             newview IN varchar2) return varchar2 as
    cCheck       number;
    cleanOldview varchar2(128);
    cleanNewview varchar2(128);
  begin

    -- Check if owner already exist
    execute immediate 'SELECT COUNT(*) FROM USER$ WHERE NAME = :1'
             into cCheck using owner;
    if (cCheck = 0) then
      RETURN NULL;
    end if;

    -- Check if oldview already exist
    execute immediate 'SELECT COUNT(*) FROM OBJ$ WHERE NAME = :1' ||
                      ' AND (TYPE# = 4 OR TYPE# = 2)'
             into cCheck using oldview;
    if (cCheck = 0) then
      RETURN NULL;
    end if;

    if (not REGEXP_LIKE(newview, '^[A-Za-z_][A-Za-z0-9_$#]*$')) then
      RETURN NULL;
    end if;

    -- Check for appropriate newview name
    -- The following is allowed for newview name
    -- 1. Substitute 'DBA' with 'CDB'
    -- 2. Substitute 'AWR_PDB' with 'CDB_HIST'
    -- 3. Substitute 'ATTRIBUTES' with 'ATTRIB'
    -- 4. Substitute 'DATABASE' with 'CDB'
    -- 5. Remove 'REDUCED'
    -- 6. Add 'AWRI$_CDB'
    cleanOldview := REGEXP_REPLACE(oldview,
       'DBA|DATABASE|_| |HIST|ATTRIB(UTE)?S?|CDB|AWR_PDB|REDUCED');
    cleanNewview := REGEXP_REPLACE(newview,
       'CDB|DATABASE|_| |HIST|ATTRIB(UTE)?S?|AWRI\$');

    if (cleanOldview <> cleanNewview) then
      RETURN NULL;
    end if;

    RETURN newview;

  end isLegalOwnerViewName;

end CDBView;
/

