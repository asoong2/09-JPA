create procedure DBMS_FEATURE_IM_JOINGROUPS(
    feature_boolean OUT NUMBER,
    aux_count       OUT NUMBER,
    feature_info    OUT CLOB)
AS
    feature_usage               varchar2(1000);
    num_jg                      number;
    inmemory_size_value         number;
BEGIN
    feature_boolean             := 0;
    aux_count                   := 0;
    inmemory_size_value         := 0;

    execute immediate
        'select count(distinct(domain#)) from im_joingroup$'
    into num_jg;

    -- check the value of the parameter "inmemory_size" from
    -- all instances
    execute immediate
       'select nvl(max(value),0) from gv$parameter where ' ||
       'name = ''inmemory_size'''
    into inmemory_size_value;

    --Summary
    feature_usage :=
        ' In-Memory Join Groups Feature Usage: ' ||
                ' Number of join groups created: ' ||
                  to_char(num_jg);

     if ((num_jg > 0) AND (inmemory_size_value > 0)) then
      feature_boolean := 1;
      feature_info := to_clob(feature_usage);
    end if;
END;
/

