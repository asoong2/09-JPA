create package dbms_flashback_archive AUTHID CURRENT_USER as

-- FDA Disassociation
procedure disassociate_fba(owner_name VARCHAR2, table_name VARCHAR2);
procedure reassociate_fba(owner_name VARCHAR2, table_name VARCHAR2);

-- FDA context
procedure set_context_level(level VARCHAR2);
function get_sys_context(xid raw, namespace varchar2, parameter varchar2)
return VARCHAR2;
procedure purge_context;

-- Extends time mappings to times in the past
procedure extend_mappings;

--User generated History
-- creates a table called temp_history with the correct definition in schema
procedure create_temp_history_table (owner_name1 IN VARCHAR2,
                                     table_name1 IN VARCHAR2) ;

-- Import History constants
nodrop    constant binary_integer := 1;
nocommit  constant binary_integer := 2;
nodelete  constant binary_integer := 4;

-- imports history from a table called temp_history in the given schema
procedure import_history (owner_name1 IN VARCHAR2, table_name1 IN VARCHAR2,
                          temp_history_name IN VARCHAR2 default 'TEMP_HISTORY',
                          options IN BINARY_INTEGER default 0);

-- DB Hardening
procedure register_application(Application_name IN VARCHAR2,
                               flashback_archive_name IN VARCHAR2 default '');
procedure add_table_to_application(Application_name IN VARCHAR2,
                                   table_name IN VARCHAR2,
                                   schema_name IN VARCHAR2 default '');
procedure remove_table_from_application (Application_name IN VARCHAR2,
                                       table_name IN VARCHAR2,
                                       schema_name IN VARCHAR2 default '');
procedure enable_application(Application_name IN VARCHAR2,
                             flashback_archive_name IN VARCHAR2 default '');
procedure disable_application(Application_name IN VARCHAR2);
procedure lock_down_application(Application_name IN VARCHAR2);
procedure unlock_application(Application_name IN VARCHAR2);
procedure drop_application(Application_name IN VARCHAR2);
procedure enable_at_valid_time(level IN VARCHAR2,
                               query_time in TIMESTAMP default SYSTIMESTAMP);
procedure disable_asof_valid_time;

end;
/

