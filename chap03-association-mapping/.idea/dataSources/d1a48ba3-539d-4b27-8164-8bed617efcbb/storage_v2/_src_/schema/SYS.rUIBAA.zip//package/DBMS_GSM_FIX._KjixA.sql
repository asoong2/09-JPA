create package dbms_gsm_fix AS

-- DE-HEAD  <- tell SED where to cut when generating fixed package

  -----------------------------------------------------------------------------
  --
  -- PROCEDURE     validateDatabase
  --
  -- Description:
  --    Validate database existence and return local DB info
  --
  -- Parameters:
  --   dbpool - dbpool that database existis in
  --   db_unique_name - unique name of database
  --   instances - number of instances database currently has configured
  --   charset - catalog character set for validation
  --   ncharset - catalog national character set for validation
  --
  -- Notes:
  --   Called from GDSCTL during 'add shard'.
  --
  -----------------------------------------------------------------------------

  PROCEDURE validateDatabase( dbpool         IN  varchar2,
                              db_unique_name OUT varchar2,
                              instances      OUT number,
                              cloud_name     IN varchar2 default NULL);

  PROCEDURE validateDatabase( dbpool              IN  varchar2,
                              db_unique_name      OUT varchar2,
                              instances           OUT number,
                              cloud_name          IN varchar2 default NULL,
                              hostname            OUT varchar2,
                              agent_port          OUT number,
                              db_sid              OUT varchar2,
                              oracle_home         OUT varchar2,
                              html_port           IN  number DEFAULT NULL,
                              registration_pass   IN varchar2 DEFAULT NULL,
                              cat_host            IN varchar2 DEFAULT NULL,
                              dbid                OUT number,
                              conversion_status   OUT varchar2,
                              gg_service          IN varchar2 DEFAULT NULL,
                              charset             IN varchar2 DEFAULT NULL,
                              ncharset            IN varchar2 DEFAULT NULL);

  -----------------------------------------------------------------------------
  -- PROCEDURE      crossValidateDatabase
  --
  -- Description:
  --     Validate that database being replaced is the correct one by comparing
  --     input parametes with parameters on this database.
  --     Parameters minobj_num and maxobj_number should be sufficient to check
  --     to detect accidental wrong input.
  --     DBID of the standby must match the primary in Data Guard replication
  --
  -- Parameters:
  --    minobj_num - old minobj_number for this database
  --    maxobj_num - old maxobj_number for this database
  --    dbid       - old dbid for this database
  -----------------------------------------------------------------------------
  PROCEDURE crossValidateDatabase( minobj_num     IN number,
                                   maxobj_num     IN number,
                                   dbid           IN number);

  -----------------------------------------------------------------------------
  --
  -- PROCEDURE     validateShard
  --
  -- Description:
  --    Validate parameters on database to-be-added to configuration by user
  --
  -- Parameters:
  --    reptype - either 'dg' or 'ogg' (case-insensitive)
  --
  --
  -- Notes:
  --   Called by users manually to validate a database prior to being added
  --   via 'add shard'.  Will display output with warnings and errors that
  --   can be corrected by user prior to 'add shard'.
  --
  -----------------------------------------------------------------------------

  PROCEDURE validateShard(reptype IN varchar2 DEFAULT 'DG');

  -----------------------------------------------------------------------------
  --
  -- PROCEDURE     setDGProperty
  --
  -- Description:
  --    Set Data Guard property in response to AQ 41 or AQ 42.
  --
  -- Parameters:
  --    params - AQ params as passed from dbms_gsm_pooladmin.setDGProperty
  --    err_num - output error number
  --    err_string - output error text
  --
  -----------------------------------------------------------------------------

  PROCEDURE setDGProperty(params     IN  varchar2,
		          err_num    OUT number,
		          err_string OUT varchar2);

end;

-- CUT_HERE    <- tell sed where to chop off the rest
/

