create PACKAGE dbms_auto_task_immediate AS
  PROCEDURE GATHER_OPTIMIZER_STATS;
END dbms_auto_task_immediate;
/

