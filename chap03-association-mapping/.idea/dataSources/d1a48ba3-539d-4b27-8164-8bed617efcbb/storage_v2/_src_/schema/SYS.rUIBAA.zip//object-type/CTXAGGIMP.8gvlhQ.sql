create type CtxAggimp                                       
   authid current_user as object
(
  key RAW(8),

  static function ODCIAggregateInitialize(sctx OUT CtxAggimp, outopn IN RAW,
                                          inpopn IN RAW ) return pls_integer
    is language c
    name "KciCtxAggInitialize"
    library kci_ctxagg_lib
    with context
    parameters (
      context,
      sctx, sctx INDICATOR STRUCT, sctx DURATION OCIDuration,
      outopn OCIRaw,
      inpopn OCIRaw,
      return INT
    ),

  member function ODCIAggregateIterate(self IN OUT NOCOPY CtxAggimp,
                                       value IN AnyData) return pls_integer
    is language c
    name "KciCtxAggIterate"
    library kci_ctxagg_lib
    with context
    parameters (
      context,
      self, self INDICATOR STRUCT, self DURATION OCIDuration,
      value, value INDICATOR sb2,
      return INT
    ),

  member function ODCIAggregateTerminate(self IN OUT NOCOPY CtxAggimp,
                                         returnValue OUT BLOB,
                                         flags IN number)
                  return pls_integer
    is language c
    name "KciCtxAggTerminate"
    library kci_ctxagg_lib
    with context
    parameters (
      context,
      self, self INDICATOR STRUCT,
      returnValue, returnValue INDICATOR sb2, returnValue DURATION OCIDuration,
      flags, flags INDICATOR sb2,
      return INT
    ),

  member function ODCIAggregateMerge(self IN OUT NOCOPY CtxAggimp,
                                     valueB IN CtxAggimp) return pls_integer
    is language c
    name "KciCtxAggMerge"
    library kci_ctxagg_lib
    with context
    parameters (
      context,
      self, self INDICATOR STRUCT, self DURATION OCIDuration,
      valueB, valueB INDICATOR STRUCT,
      return INT
    ),

  member function ODCIAggregateWrapContext(self IN OUT NOCOPY CtxAggimp)
                  return pls_integer
    is language c
    name "KciCtxAggWrap"
    library kci_ctxagg_lib
    with context
    parameters (
      context,
      self, self INDICATOR STRUCT, self DURATION OCIDuration,
      return INT
    )
);
/

