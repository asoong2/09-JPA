create type aq$_jms_exception
                                      
as object
(
  id          number, -- reserved for later use
  exp_name    varchar(200),
  err_msg     varchar(500),
  stack       varchar(4000)
);
/

