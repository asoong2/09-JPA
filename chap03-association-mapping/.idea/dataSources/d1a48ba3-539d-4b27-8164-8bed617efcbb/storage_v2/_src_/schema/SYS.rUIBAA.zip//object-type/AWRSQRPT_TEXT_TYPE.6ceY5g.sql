create type AWRSQRPT_TEXT_TYPE
  as object (output varchar2(120 CHAR))
/

